#ifndef GAMEMAP_H
#define GAMEMAP_H


class GameMap
{
    public:
        GameMap() {}
        virtual ~GameMap() {}

    protected:

    private:
};

#endif // GAMEMAP_H
