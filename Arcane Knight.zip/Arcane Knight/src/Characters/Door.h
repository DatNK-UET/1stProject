#ifndef DOOR_H
#define DOOR_H

#include "GameObject.h"
#include "RigidBody.h"

class Door : public GameObject {
public:
    Door(float x, float y, int width, int height);
    void setPosition(float x, float y) override;
    void update(float deltaTime) override;
    void render(SDL_Renderer* renderer) override;
    RigidBody* getRigidBody() const override;
    int getWidth() const override;
    int getHeight() const override;

private:
    RigidBody* rigidBody;
    int width;
    int height;
};

#endif
