#include "Bullet.h"
#include "Camera.h"
#include <SDL.h>

Bullet::Bullet(float x, float y, float speedX, float speedY) : width(8), height(8), active(true) {
    rigidBody = new RigidBody();
    rigidBody->position = Vector2D(x, y);
    rigidBody->velocity = Vector2D(speedX, speedY);
}

void Bullet::setPosition(float x, float y) {
    rigidBody->position.x = x;
    rigidBody->position.y = y;
}

void Bullet::update(float deltaTime) {
    if (active) {
        rigidBody->update(deltaTime);
    }
}

void Bullet::render(SDL_Renderer* renderer) {
    if (active) {
        int offsetX = Camera::getInstance()->getOffsetX();
        int offsetY = Camera::getInstance()->getOffsetY();

        SDL_Rect rect = {
            static_cast<int>(rigidBody->position.x - offsetX),
            static_cast<int>(rigidBody->position.y - offsetY),
            width,
            height
        };
        SDL_SetRenderDrawColor(renderer, 255, 255, 0, 255);
        SDL_RenderFillRect(renderer, &rect);
    }
}
