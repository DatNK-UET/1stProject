#ifndef WARRIOR_H
#define WARRIOR_H

#include "../Physics/RigidBody.h"
#include "Bullet.h"
#include "GameObject.h"
#include <SDL.h>
#include <vector>
#include <map>

class Warrior : public GameObject {
public:

    enum class AnimationState {
        IDLE,
        RUN,
        DEATH
    };

    Warrior();
    virtual ~Warrior();
    void init();
    void setPosition(float x, float y);
    void setMapBounds(float mapWidth, float mapHeight, float tileWidth, float tileHeight, float scaleFactor);
    void loadTextures(SDL_Renderer* renderer);
    void updateAnimation(float deltaTime);
    virtual void update(float deltaTime) override;
    virtual void render(SDL_Renderer* renderer) override;

    RigidBody* getRigidBody() const;
    int getWidth() const;
    int getHeight() const;
    std::vector<Bullet*>& getBullets();
    void setOnGround(bool grounded);
    bool isOnGround() const;
    int getLastDirection() const;

private:
    RigidBody* rigidBody;
    bool onGround;
    bool canJump;
    int width;
    int height;
    float mapWidth_;
    float mapHeight_;
    float tileWidth_;
    float tileHeight_;
    float scaleFactor_;
    int lastDirection;
    std::vector<Bullet*> bullets;
    bool isMovingSoundPlaying;


    AnimationState currentState;
    bool isDead_;
    int currentFrame;
    float animationTimer;
    float frameTime;
    std::map<AnimationState, int> frameCounts;
    std::map<AnimationState, int> frameWidths;
    std::map<AnimationState, int> frameHeights;
    std::map<AnimationState, int> rowCounts;
    std::map<AnimationState, SDL_Texture*> textures;
};

#endif // WARRIOR_H
