#include "Door.h"
#include "Camera.h"
#include <SDL.h>

Door::Door(float x, float y, int width, int height) : width(width), height(height) {
    rigidBody = new RigidBody();
    rigidBody->position = Vector2D(x, y);
}

void Door::setPosition(float x, float y) {
    rigidBody->position.x = x;
    rigidBody->position.y = y;
}

void Door::update(float deltaTime) {

}

void Door::render(SDL_Renderer* renderer) {
    int offsetX = Camera::getInstance()->getOffsetX();
    int offsetY = Camera::getInstance()->getOffsetY();

    SDL_Rect rect = {
        static_cast<int>(rigidBody->position.x - offsetX),
        static_cast<int>(rigidBody->position.y - offsetY),
        width,
        height
    };
    SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
    SDL_RenderFillRect(renderer, &rect);
}

RigidBody* Door::getRigidBody() const {
    return rigidBody;
}

int Door::getWidth() const {
    return width;
}

int Door::getHeight() const {
    return height;
}
