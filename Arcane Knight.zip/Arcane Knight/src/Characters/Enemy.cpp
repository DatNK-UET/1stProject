#include "Enemy.h"
#include "Camera.h"
#include "../Graphics/TextureManager.h"
#include <SDL.h>
#include <iostream>
#include <SDL_image.h>

Enemy::Enemy() : rigidBody(new RigidBody()), active(true), onGround(false), width(24), height(24),
                 patrolRange(100.0f), patrolCenterX(0.0f), patrolSpeed(100.0f),
                 currentState(AnimationState::PATROL), currentFrame(0), animationTimer(0.0f), frameTime(0.1f) {

    frameCounts[AnimationState::PATROL] = 4;
    frameWidths[AnimationState::PATROL] = 24;
    frameHeights[AnimationState::PATROL] = 24;
    rowCounts[AnimationState::PATROL] = 1;
}

Enemy::~Enemy() {
    delete rigidBody;
    for (auto& texture : textures) {
        if (texture.second) SDL_DestroyTexture(texture.second);
    }
    textures.clear();
}

void Enemy::setPosition(float x, float y) {
    rigidBody->position.x = x;
    rigidBody->position.y = y;
    patrolCenterX = x;
}

void Enemy::setPatrolRange(float range, float centerX) {
    patrolRange = range;
    patrolCenterX = centerX;
}

void Enemy::loadTextures(SDL_Renderer* renderer) {
    std::cout << "Loading textures for Enemy..." << std::endl;

    textures[AnimationState::PATROL] = TextureManager::getInstance()->loadTexture("assets/sprites/slime.png");
    if (!textures[AnimationState::PATROL]) {
        std::cout << "Failed to load enemy_patrol.png: " << IMG_GetError() << std::endl;
    } else {
        std::cout << "Loaded enemy_patrol.png successfully" << std::endl;
    }
}

void Enemy::updateAnimation(float deltaTime) {
    animationTimer += deltaTime;
    if (animationTimer >= frameTime) {
        animationTimer -= frameTime;
        currentFrame = (currentFrame + 1) % frameCounts[currentState];
    }
}

void Enemy::update(float deltaTime) {
    if (!active) return;


    currentState = AnimationState::PATROL;
    updateAnimation(deltaTime);


    if (!onGround) {
        rigidBody->acceleration.y = 200.0f;
    } else {
        rigidBody->acceleration.y = 0;
        rigidBody->velocity.y = 0;


        float currentX = rigidBody->position.x;
        float leftBound = patrolCenterX - patrolRange / 2;
        float rightBound = patrolCenterX + patrolRange / 2;

        if (currentX < leftBound) {
            rigidBody->velocity.x = patrolSpeed;
        } else if (currentX > rightBound) {
            rigidBody->velocity.x = -patrolSpeed;
        }

        if (rigidBody->velocity.x == 0.0f) {
            rigidBody->velocity.x = patrolSpeed;
        }

        std::cout << "Enemy posX=" << currentX << ", velocityX=" << rigidBody->velocity.x
                  << ", leftBound=" << leftBound << ", rightBound=" << rightBound << "\n";
    }

    rigidBody->update(deltaTime);
}

void Enemy::render(SDL_Renderer* renderer) {
    if (!active) return;

    if (!textures[currentState]) {
        std::cout << "No texture for state " << static_cast<int>(currentState) << ", rendering fallback\n";
        int offsetX = Camera::getInstance()->getOffsetX();
        int offsetY = Camera::getInstance()->getOffsetY();

        SDL_Rect rect = {
            static_cast<int>(rigidBody->position.x - offsetX),
            static_cast<int>(rigidBody->position.y - offsetY),
            width,
            height
        };
        SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
        SDL_RenderFillRect(renderer, &rect);
        return;
    }

    int offsetX = Camera::getInstance()->getOffsetX();
    int offsetY = Camera::getInstance()->getOffsetY();


    int framesPerRow = frameCounts[currentState];
    int currentRow = 0;
    int frameInRow = currentFrame;

    SDL_Rect src = {
        frameInRow * frameWidths[currentState],
        currentRow * frameHeights[currentState],
        frameWidths[currentState],
        frameHeights[currentState]
    };

    SDL_Rect dst = {
        static_cast<int>(rigidBody->position.x - offsetX),
        static_cast<int>(rigidBody->position.y - offsetY),
        width,
        height
    };


    SDL_RendererFlip flip = (rigidBody->velocity.x < 0) ? SDL_FLIP_HORIZONTAL : SDL_FLIP_NONE;
    SDL_RenderCopyEx(renderer, textures[currentState], &src, &dst, 0.0, nullptr, flip);
}

RigidBody* Enemy::getRigidBody() const { return rigidBody; }
int Enemy::getWidth() const { return width; }
int Enemy::getHeight() const { return height; }
void Enemy::setOnGround(bool grounded) { onGround = grounded; }
void Enemy::setActive(bool act) { active = act; }
bool Enemy::isActive() const { return active; }
bool Enemy::isOnGround() const { return onGround; }
