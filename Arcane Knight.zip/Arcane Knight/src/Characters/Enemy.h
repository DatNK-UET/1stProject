#ifndef ENEMY_H
#define ENEMY_H

#include "RigidBody.h"
#include "GameObject.h"
#include <SDL.h>
#include <map>

class Enemy : public GameObject {
protected:
    RigidBody* rigidBody;
    bool active;
    bool onGround;
    int width;
    int height;
    float patrolRange;
    float patrolCenterX;
    float patrolSpeed;


    enum class AnimationState {
        PATROL
    };
    AnimationState currentState;
    int currentFrame;
    float animationTimer;
    float frameTime;
    std::map<AnimationState, int> frameCounts;
    std::map<AnimationState, int> frameWidths;
    std::map<AnimationState, int> frameHeights;
    std::map<AnimationState, int> rowCounts;
    std::map<AnimationState, SDL_Texture*> textures;

public:
    Enemy();
    virtual ~Enemy();
    virtual void setPosition(float x, float y) override;
    virtual void update(float deltaTime) override;
    virtual void render(SDL_Renderer* renderer) override;
    virtual RigidBody* getRigidBody() const override;
    virtual int getWidth() const override;
    virtual int getHeight() const override;
    virtual void setOnGround(bool ground);
    virtual void setActive(bool act);
    virtual bool isActive() const;
    virtual bool isOnGround() const;
    void setPatrolRange(float range, float centerX);
    void loadTextures(SDL_Renderer* renderer);
    void updateAnimation(float deltaTime);
};

#endif
