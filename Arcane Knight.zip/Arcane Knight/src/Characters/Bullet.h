#ifndef BULLET_H
#define BULLET_H

#include "GameObject.h"
#include "RigidBody.h"

class Bullet : public GameObject {
public:
    Bullet(float x, float y, float speedX, float speedY);
    void setPosition(float x, float y) override;
    void update(float deltaTime) override;
    void render(SDL_Renderer* renderer) override;
    RigidBody* getRigidBody() const { return rigidBody; }
    int getWidth() const { return width; }
    int getHeight() const { return height; }
    bool isActive() const { return active; }
    void deactivate() { active = false; }

private:
    RigidBody* rigidBody;
    int width;
    int height;
    bool active;
};

#endif
