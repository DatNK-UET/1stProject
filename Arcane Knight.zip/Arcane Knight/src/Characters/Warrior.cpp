#include "Warrior.h"
#include "Input.h"
#include "Camera.h"
#include "../Graphics/TextureManager.h"
#include <SDL.h>
#include <iostream>
#include <map>
#include "SDL_image.h"
#include "AudioManager.h"

Warrior::Warrior() : rigidBody(new RigidBody()), onGround(false), canJump(false), width(32), height(32),
                    mapWidth_(0), mapHeight_(0), tileWidth_(16), tileHeight_(16), scaleFactor_(1.0f),
                    lastDirection(1), currentState(AnimationState::IDLE), isDead_(false),
                    currentFrame(0), animationTimer(0.0f), frameTime(0.1f), isMovingSoundPlaying(false) {

    frameCounts[AnimationState::IDLE] = 4;
    frameCounts[AnimationState::RUN] = 16;
    frameCounts[AnimationState::DEATH] = 4;
    frameWidths[AnimationState::IDLE] = 32;
    frameWidths[AnimationState::RUN] = 32;
    frameWidths[AnimationState::DEATH] = 32;
    frameHeights[AnimationState::IDLE] = 32;
    frameHeights[AnimationState::RUN] = 32;
    frameHeights[AnimationState::DEATH] = 32;
    rowCounts[AnimationState::IDLE] = 1;
    rowCounts[AnimationState::RUN] = 2;
    rowCounts[AnimationState::DEATH] = 1;
}

Warrior::~Warrior() {
    delete rigidBody;
    for (auto bullet : bullets) delete bullet;
    bullets.clear();
    for (auto& texture : textures) {
        if (texture.second) SDL_DestroyTexture(texture.second);
    }
    textures.clear();
}

void Warrior::setPosition(float x, float y) {
    rigidBody->position.x = x;
    rigidBody->position.y = y;
}

void Warrior::setMapBounds(float mapWidth, float mapHeight, float tileWidth, float tileHeight, float scaleFactor) {
    mapWidth_ = mapWidth;
    mapHeight_ = mapHeight;
    tileWidth_ = tileWidth;
    tileHeight_ = tileHeight;
    scaleFactor_ = scaleFactor;
    std::cout << "Map bounds set: width=" << mapWidth_ * tileWidth_ * scaleFactor_ << ", height=" << mapHeight_ * tileHeight_ * scaleFactor_ << std::endl;
}

void Warrior::loadTextures(SDL_Renderer* renderer) {
    std::cout << "Loading textures for Warrior..." << std::endl;

    textures[AnimationState::IDLE] = TextureManager::getInstance()->loadTexture("assets/sprites/warrior_idle.png");
    if (!textures[AnimationState::IDLE]) {
        std::cout << "Failed to load warrior_idle.png: " << IMG_GetError() << std::endl;
    } else {
        std::cout << "Loaded warrior_idle.png successfully" << std::endl;
    }

    textures[AnimationState::RUN] = TextureManager::getInstance()->loadTexture("assets/sprites/warrior_run.png");
    if (!textures[AnimationState::RUN]) {
        std::cout << "Failed to load warrior_run.png: " << IMG_GetError() << std::endl;
    } else {
        std::cout << "Loaded warrior_run.png successfully" << std::endl;
    }

    textures[AnimationState::DEATH] = TextureManager::getInstance()->loadTexture("assets/sprites/warrior_death.png");
    if (!textures[AnimationState::DEATH]) {
        std::cout << "Failed to load warrior_death.png: " << IMG_GetError() << std::endl;
    } else {
        std::cout << "Loaded warrior_death.png successfully" << std::endl;
    }
}

void Warrior::updateAnimation(float deltaTime) {
    animationTimer += deltaTime;
    if (animationTimer >= frameTime) {
        animationTimer -= frameTime;
        currentFrame = (currentFrame + 1) % frameCounts[currentState];
        if (currentState == AnimationState::DEATH && currentFrame == frameCounts[AnimationState::DEATH] - 1) {
            currentFrame = frameCounts[AnimationState::DEATH] - 1;
        }
    }
}

void Warrior::update(float deltaTime) {
    if (isDead_) {
        currentState = AnimationState::DEATH;
        updateAnimation(deltaTime);
        return;
    }

    rigidBody->acceleration.x = 0.0f;

    bool isMoving = false;
    if (Input::getInstance()->isKeyDown(SDLK_a)) {
        rigidBody->velocity.x = -200.0f;
        lastDirection = -1;
        currentState = AnimationState::RUN;
        isMoving = true;
        std::cout << "Moving left, velocity.x = " << rigidBody->velocity.x << ", lastDirection = " << lastDirection << std::endl;
    } else if (Input::getInstance()->isKeyDown(SDLK_d)) {
        rigidBody->velocity.x = 200.0f;
        lastDirection = 1;
        currentState = AnimationState::RUN;
        isMoving = true;
        std::cout << "Moving right, velocity.x = " << rigidBody->velocity.x << ", lastDirection = " << lastDirection << std::endl;
    } else {
        rigidBody->velocity.x = 0.0f;
        currentState = AnimationState::IDLE;
    }


    if (isMoving && !isMovingSoundPlaying) {
        AudioManager::GetInstance()->PlaySound("assets/audio/move.mp3", 0);
        isMovingSoundPlaying = true;
    } else if (!isMoving && isMovingSoundPlaying) {
        isMovingSoundPlaying = false;
    }

    if (Input::getInstance()->isKeyDown(SDLK_SPACE) && onGround && canJump) {
        rigidBody->velocity.y = -758.9f;
        rigidBody->acceleration.y = 0.0f;
        onGround = false;
        canJump = false;
        AudioManager::GetInstance()->PlaySound("assets/audio/jump.mp3", 0);
        std::cout << "Jumping initiated, velocity.y = " << rigidBody->velocity.y << ", onGround = false, canJump = false" << std::endl;
    }

    updateAnimation(deltaTime);
}

void Warrior::render(SDL_Renderer* renderer) {
    if (!textures[currentState]) {
        std::cout << "No texture for state " << static_cast<int>(currentState) << ", rendering fallback\n";
        SDL_Rect rect = {
            static_cast<int>(rigidBody->position.x - Camera::getInstance()->getOffsetX()),
            static_cast<int>(rigidBody->position.y - Camera::getInstance()->getOffsetY()),
            width,
            height
        };
        SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
        SDL_RenderFillRect(renderer, &rect);
        SDL_SetRenderDrawColor(renderer, 255, 0, 0, 100);
        SDL_RenderDrawRect(renderer, &rect);
        return;
    }


    if (textures[AnimationState::IDLE] == nullptr) {
        loadTextures(renderer);
    }


    int framesPerRow = frameCounts[currentState] / rowCounts[currentState];
    int currentRow = currentFrame / framesPerRow;
    int frameInRow = currentFrame % framesPerRow;

    SDL_Rect src = {
        frameInRow * frameWidths[currentState],
        currentRow * frameHeights[currentState],
        frameWidths[currentState],
        frameHeights[currentState]
    };

    SDL_Rect dst = {
        static_cast<int>(rigidBody->position.x - Camera::getInstance()->getOffsetX()),
        static_cast<int>(rigidBody->position.y - Camera::getInstance()->getOffsetY()),
        width,
        height
    };

    SDL_RendererFlip flip = (lastDirection < 0) ? SDL_FLIP_HORIZONTAL : SDL_FLIP_NONE;
    SDL_RenderCopyEx(renderer, textures[currentState], &src, &dst, 0.0, nullptr, flip);
}

RigidBody* Warrior::getRigidBody() const { return rigidBody; }
int Warrior::getWidth() const { return width; }
int Warrior::getHeight() const { return height; }
std::vector<Bullet*>& Warrior::getBullets() { return bullets; }
void Warrior::setOnGround(bool grounded) {
    onGround = grounded;
    if (grounded) {
        canJump = true;
        std::cout << "Set onGround = true, canJump = true" << std::endl;
    }
}
bool Warrior::isOnGround() const { return onGround; }


void Warrior::init() {
    std::cout << "Initializing Warrior..." << std::endl;

    rigidBody->position = Vector2D(0, 0);
    rigidBody->velocity = Vector2D(0, 0);
    rigidBody->acceleration = Vector2D(0, 5000);
    onGround = false;
    canJump = false;
    isDead_ = false;
    currentState = AnimationState::IDLE;
    currentFrame = 0;
    animationTimer = 0.0f;
    lastDirection = 1;
    bullets.clear();
}

int Warrior::getLastDirection() const {
    return lastDirection;
}
