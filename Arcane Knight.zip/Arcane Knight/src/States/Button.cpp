#include "Button.h"

Button::Button(int x, int y, int w, int h, const std::string& text, std::function<void()> onClick)
    : text(text), onClick(onClick), font(nullptr), textTexture(nullptr), isHovered(false) {
    rect = {x, y, w, h};
    font = TTF_OpenFont("assets/arial.ttf", 24);
}

Button::~Button() {
    if (textTexture) SDL_DestroyTexture(textTexture);
    if (font) TTF_CloseFont(font);
}

void Button::update() {
    int mouseX, mouseY;
    SDL_GetMouseState(&mouseX, &mouseY);
    isHovered = (mouseX >= rect.x && mouseX <= rect.x + rect.w &&
                 mouseY >= rect.y && mouseY <= rect.y + rect.h);
}

void Button::updateTextTexture(SDL_Renderer* renderer) {
    if (!font) return;
    if (textTexture) SDL_DestroyTexture(textTexture);

    SDL_Color color = { 0, 0, 0, 255 };
    SDL_Surface* surface = TTF_RenderText_Solid(font, text.c_str(), color);
    if (surface) {
        textTexture = SDL_CreateTextureFromSurface(renderer, surface);

        textRect.w = surface->w;
        textRect.h = surface->h;
        textRect.x = rect.x + (rect.w - surface->w) / 2;
        textRect.y = rect.y + (rect.h - surface->h) / 2;
        SDL_FreeSurface(surface);
    }
}

void Button::render(SDL_Renderer* renderer) {

    bool isLocked = text.find("(Locked)") != std::string::npos;

    SDL_SetRenderDrawColor(renderer,
        isLocked ? 255 : (isHovered ? 200 : 255),
        isLocked ? 0 : 255,
        isLocked ? 0 : 255,
        255);
    SDL_RenderFillRect(renderer, &rect);
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderDrawRect(renderer, &rect);

    updateTextTexture(renderer);
    if (textTexture) {
        SDL_RenderCopy(renderer, textTexture, nullptr, &textRect);
    }
}

bool Button::handleEvent(SDL_Event& event) {
    if (event.type == SDL_MOUSEBUTTONDOWN) {
        int mouseX = event.button.x;
        int mouseY = event.button.y;
        if (mouseX >= rect.x && mouseX <= rect.x + rect.w &&
            mouseY >= rect.y && mouseY <= rect.y + rect.h) {
            onClick();
            return true;
        }
    }
    return false;
}
