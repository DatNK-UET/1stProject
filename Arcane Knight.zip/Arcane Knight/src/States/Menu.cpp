#include "Menu.h"
#include "Engine.h"
#include "../Audio/AudioManager.h"
#include <TextureManager.h>

Menu::~Menu() {
    for (auto button : buttons) delete button;
    buttons.clear();
    if (backgroundTexture) SDL_DestroyTexture(backgroundTexture);
    AudioManager::GetInstance()->StopMusic();
}

void Menu::init() {
    buttons.clear();

    buttons.push_back(new Button(300, 350, 200, 50, "PLAY", []() {
        Engine::getInstance()->setState(GameStateEnum::LEVEL_SELECTION);
    }));
    buttons.push_back(new Button(300, 450, 200, 50, "QUIT", []() {
        Engine::getInstance()->quit();
    }));
    backgroundTexture = TextureManager::getInstance()->loadTexture("assets/background_menu.jpg");


    AudioManager::GetInstance()->PlayMusic("assets/audio/menu.mp3", -1);
}

void Menu::update(float deltaTime) {
    for (auto button : buttons) {
        if (button) {
            button->update();
        }
    }
}

void Menu::render(SDL_Renderer* renderer) {
    if (!renderer) return;

    if (backgroundTexture) {
        SDL_RenderCopy(renderer, backgroundTexture, nullptr, nullptr);
    } else {
        SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
        SDL_Rect rect = {0, 0, 800, 600};
        SDL_RenderFillRect(renderer, &rect);
    }

    for (auto button : buttons) {
        if (button) {
            button->render(renderer);
        }
    }
}

void Menu::handleEvents(SDL_Event& event) {
    for (auto button : buttons) {
        if (button) {
            button->handleEvent(event);
        }
    }
}
