#include "Play.h"
#include "Input.h"
#include "CollisionHandler.h"
#include "Camera.h"
#include "MapParser.h"
#include "../Factory/ObjectFactory.h"
#include "Engine.h"
#include "LevelComplete.h"
#include <algorithm>
#include <iostream>
#include "AudioManager.h"

Play::Play() : gameMap(nullptr), player(nullptr), door(nullptr), font(nullptr), timerTexture(nullptr),
               startTime(0), elapsedTime(0.0f), bulletCooldown(0.5f), lastShotTime(0.0f), currentLevel(1) {}

void Play::setLevel(int level) {
    std::cout << "Setting level to " << level << std::endl;
    currentLevel = level;
}

void Play::spawnEnemies() {

    for (auto enemy : enemies) {
        if (enemy) delete enemy;
    }
    enemies.clear();

    float scaledTileSize = gameMap->getTileWidth() * gameMap->getScaleFactor();

    if (currentLevel == 1) {

        Enemy* enemy1 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy1) {
            enemy1->setPosition(20 * scaledTileSize, 34 * scaledTileSize - enemy1->getHeight());
            enemy1->setPatrolRange(200.0f, 20 * scaledTileSize);
            enemy1->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy1);
        }

        Enemy* enemy2 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy2) {
            enemy2->setPosition(30 * scaledTileSize, 34 * scaledTileSize - enemy2->getHeight());
            enemy2->setPatrolRange(150.0f, 30 * scaledTileSize);
            enemy2->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy2);
        }
        Enemy* enemy3 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy3) {
            enemy3->setPosition(51 * scaledTileSize, 29 * scaledTileSize - enemy1->getHeight());
            enemy3->setPatrolRange(200.0f, 20 * scaledTileSize);
            enemy3->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy3);
        }

        Enemy* enemy4 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy4) {
            enemy4->setPosition(12 * scaledTileSize, 21 * scaledTileSize - enemy1->getHeight());
            enemy4->setPatrolRange(200.0f, 20 * scaledTileSize);
            enemy4->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy4);
        }

        Enemy* enemy5 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy5) {
            enemy5->setPosition(27 * scaledTileSize, 20 * scaledTileSize - enemy1->getHeight());
            enemy5->setPatrolRange(200.0f, 20 * scaledTileSize);
            enemy5->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy5);
        }

        Enemy* enemy6 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy6) {
            enemy6->setPosition(74 * scaledTileSize, 31 * scaledTileSize - enemy1->getHeight());
            enemy6->setPatrolRange(200.0f, 20 * scaledTileSize);
            enemy6->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy6);
        }
        Enemy* enemy7 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy7) {
            enemy7->setPosition( 92 * scaledTileSize, 29 * scaledTileSize - enemy1->getHeight());
            enemy7->setPatrolRange(200.0f, 20 * scaledTileSize);
            enemy7->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy7);
        }
Enemy* enemy8 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy8) {
            enemy8->setPosition(104 * scaledTileSize, 12 * scaledTileSize - enemy1->getHeight());
            enemy8->setPatrolRange(200.0f, 20 * scaledTileSize);
            enemy8->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy8);
        }
Enemy* enemy9 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy9) {
            enemy9->setPosition(81 * scaledTileSize, 18 * scaledTileSize - enemy1->getHeight());
            enemy9->setPatrolRange(200.0f, 20 * scaledTileSize);
            enemy9->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy9);
        }

    } else if (currentLevel == 2) {

        Enemy* enemy1 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy1) {
            enemy1->setPosition(50 * scaledTileSize, 8 * scaledTileSize - enemy1->getHeight());
            enemy1->setPatrolRange(200.0f, 40 * scaledTileSize);
            enemy1->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy1);
        }

        Enemy* enemy2 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy2) {
            enemy2->setPosition(31 * scaledTileSize, 6 * scaledTileSize - enemy2->getHeight());
            enemy2->setPatrolRange(250.0f, 60 * scaledTileSize);
            enemy2->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy2);
        }

        Enemy* enemy4 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy4) {
            enemy4->setPosition(46 * scaledTileSize, 19 * scaledTileSize - enemy4->getHeight());
            enemy4->setPatrolRange(200.0f, 80 * scaledTileSize);
            enemy4->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy4);
        }
        Enemy* enemy5 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy5) {
            enemy5->setPosition(77 * scaledTileSize, 26 * scaledTileSize - enemy5->getHeight());
            enemy5->setPatrolRange(200.0f, 80 * scaledTileSize);
            enemy5->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy5);
        }
        Enemy* enemy6 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy6) {
            enemy6->setPosition(88 * scaledTileSize, 23 * scaledTileSize - enemy6->getHeight());
            enemy6->setPatrolRange(200.0f, 80 * scaledTileSize);
            enemy6->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy6);
        }
        Enemy* enemy7 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy7) {
            enemy7->setPosition(25 * scaledTileSize, 20 * scaledTileSize - enemy7->getHeight());
            enemy7->setPatrolRange(200.0f, 80 * scaledTileSize);
            enemy7->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy7);
        }
        Enemy* enemy8 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy8) {
            enemy8->setPosition(34 * scaledTileSize, 34 * scaledTileSize - enemy8->getHeight());
            enemy8->setPatrolRange(200.0f, 80 * scaledTileSize);
            enemy8->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy8);
        }
        Enemy* enemy9 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy9) {
            enemy9->setPosition(68 * scaledTileSize, 31 * scaledTileSize - enemy9->getHeight());
            enemy9->setPatrolRange(200.0f, 80 * scaledTileSize);
            enemy9->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy9);
        }
    } else if (currentLevel == 3) {

        Enemy* enemy1 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy1) {
            enemy1->setPosition(50 * scaledTileSize, 30 * scaledTileSize - enemy1->getHeight());
            enemy1->setPatrolRange(400.0f, 50 * scaledTileSize);
            enemy1->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy1);
        }

        Enemy* enemy2 = dynamic_cast<Enemy*>(ObjectFactory::getInstance()->createObject("Enemy"));
        if (enemy2) {
            enemy2->setPosition(70 * scaledTileSize, 30 * scaledTileSize - enemy2->getHeight());
            enemy2->setPatrolRange(350.0f, 70 * scaledTileSize);
            enemy2->loadTextures(Engine::getInstance()->getRenderer());
            enemies.push_back(enemy2);
        }
    }


    for (auto enemy : enemies) {
        if (enemy) CollisionHandler::getInstance()->checkCollisions(enemy, gameMap, 0.0f);
    }

    std::cout << "Spawned " << enemies.size() << " enemies for level " << currentLevel << std::endl;
}


void Play::init() {
    std::cout << "Initializing Play state for level " << currentLevel << std::endl;


    if (player) {
        for (auto bullet : player->getBullets()) delete bullet;
        player->getBullets().clear();
        delete player;
        player = nullptr;
    }
    for (auto enemy : enemies) {
        if (enemy) delete enemy;
    }
    enemies.clear();
    if (door) {
        delete door;
        door = nullptr;
    }
    if (timerTexture) {
        SDL_DestroyTexture(timerTexture);
        timerTexture = nullptr;
    }
    if (font) {
        TTF_CloseFont(font);
        font = nullptr;
    }


    std::string mapFile = currentLevel == 1 ? "assets/maps/map1.tmx" : "assets/maps/map2.tmx";
    std::cout << "Attempting to load map: " << mapFile << std::endl;
    MapParser* parser = MapParser::getInstance();
    parser->clean();
    if (!parser->loadMap(mapFile)) {
        std::cout << "Failed to load map: " << mapFile << std::endl;
        Engine::getInstance()->setState(GameStateEnum::MENU);
        return;
    }
    gameMap = parser->getGameMap();
    if (!gameMap) {
        std::cout << "GameMap is null after loading " << mapFile << std::endl;
        Engine::getInstance()->setState(GameStateEnum::MENU);
        return;
    }
    std::cout << "Loaded map with " << gameMap->getLayerCount() << " layers" << std::endl;
    gameMap->setScaleFactor(1.5f);


    player = dynamic_cast<Warrior*>(ObjectFactory::getInstance()->createObject("Warrior"));
    if (!player) {
        std::cout << "Failed to create Warrior" << std::endl;
        Engine::getInstance()->setState(GameStateEnum::MENU);
        return;
    }
    player->init();
    std::cout << "Calling loadTextures for Warrior..." << std::endl;
    player->loadTextures(Engine::getInstance()->getRenderer());
    float scaledTileSize = gameMap->getTileWidth() * gameMap->getScaleFactor();
    float playerX, playerY, doorX, doorY;
    if (currentLevel == 1) {
        playerX = 1 * scaledTileSize;
        playerY = 34 * scaledTileSize - player->getHeight();
        doorX = 0 * scaledTileSize;
        doorY = 0 * scaledTileSize;
    } else {
        playerX = 1 * scaledTileSize;
        playerY = 1 * scaledTileSize;
        doorX = 119 * scaledTileSize;
        doorY = 35 * scaledTileSize;
    }
    player->setPosition(playerX, playerY);
    std::cout << "Player positioned at (" << playerX << ", " << playerY << ")" << std::endl;
    player->setMapBounds(
        gameMap->getMapWidth(),
        gameMap->getMapHeight(),
        gameMap->getTileWidth(),
        gameMap->getTileHeight(),
        gameMap->getScaleFactor()
    );
    CollisionHandler::getInstance()->checkCollisions(player, gameMap, 0.0f);


    spawnEnemies();


    door = dynamic_cast<Door*>(ObjectFactory::getInstance()->createObject("Door"));
    if (door) {
        door->setPosition(doorX, doorY);
        std::cout << "Door initialized at (" << doorX << ", " << doorY << ") for level " << currentLevel << std::endl;
    } else {
        std::cout << "Failed to create Door" << std::endl;
        Engine::getInstance()->setState(GameStateEnum::MENU);
        return;
    }


    Camera::getInstance()->setViewport(800, 600);
    float scaleFactor = gameMap->getScaleFactor();
    Camera::getInstance()->setMapDimensions(
        gameMap->getMapWidth() * gameMap->getTileWidth() * scaleFactor,
        gameMap->getMapHeight() * gameMap->getTileHeight() * scaleFactor
    );
    Camera::getInstance()->follow(player);


    elapsedTime = 0.0f;
    startTime = SDL_GetTicks();
    font = TTF_OpenFont("assets/arial.ttf", 24);
    if (!font) {
        std::cout << "Failed to load font: " << TTF_GetError() << std::endl;
        return;
    }
    timerRect = {10, 10, 100, 30};
    lastShotTime = 0.0f;
    updateTimerTexture(Engine::getInstance()->getRenderer());


    AudioManager::GetInstance()->PlayMusic("assets/audio/play.mp3", -1);

    std::cout << "Play state initialized successfully for level " << currentLevel << std::endl;
}



void Play::update(float deltaTime) {
    if (!player || !gameMap || !door) return;

    deltaTime = std::min(deltaTime, 1.0f / 60.0f);

    static float timeAccum = 0.0f;
    static int frameCount = 0;
    timeAccum += deltaTime;
    frameCount++;
    if (timeAccum >= 1.0f) {
        std::cout << "FPS: " << frameCount / timeAccum << std::endl;
        timeAccum = 0.0f;
        frameCount = 0;
    }

    Input::getInstance()->update();

    float currentTime = elapsedTime + (SDL_GetTicks() - startTime) / 1000.0f;
    if (Input::getInstance()->isKeyDown(SDLK_f) && currentTime - lastShotTime >= bulletCooldown) {
        auto& bullets = player->getBullets();
        float bulletX, bulletSpeedX;
        float bulletY = player->getRigidBody()->position.y + player->getHeight() / 2;
        float playerVelocityX = player->getRigidBody()->velocity.x;
        int lastDirection = player->getLastDirection();

        if (playerVelocityX > 0) {
            bulletX = player->getRigidBody()->position.x + player->getWidth();
            bulletSpeedX = 800.0f;
        } else if (playerVelocityX < 0) {
            bulletX = player->getRigidBody()->position.x;
            bulletSpeedX = -800.0f;
        } else {
            if (lastDirection > 0) {
                bulletX = player->getRigidBody()->position.x + player->getWidth();
                bulletSpeedX = 800.0f;
            } else {
                bulletX = player->getRigidBody()->position.x;
                bulletSpeedX = -800.0f;
            }
        }

        bullets.push_back(new Bullet(bulletX, bulletY, bulletSpeedX, 0.0f));
        lastShotTime = currentTime;
        AudioManager::GetInstance()->PlaySound("assets/audio/gun.mp3", 0);
        std::cout << "Bullet fired: posX=" << bulletX << ", speedX=" << bulletSpeedX << ", lastDirection=" << lastDirection << std::endl;
    }


    player->update(deltaTime);
    CollisionHandler::getInstance()->checkCollisions(player, gameMap, deltaTime);

    for (auto enemy : enemies) {
        if (enemy && enemy->isActive()) {
            enemy->update(deltaTime);
            CollisionHandler::getInstance()->checkCollisions(enemy, gameMap, deltaTime);
        }
    }

    if (CollisionHandler::getInstance()->checkObjectCollision(player, door)) {
        auto levelComplete = dynamic_cast<LevelComplete*>(Engine::getInstance()->getState(GameStateEnum::LEVEL_COMPLETE));
        if (levelComplete) levelComplete->setLevel(currentLevel);
        Engine::getInstance()->setState(GameStateEnum::LEVEL_COMPLETE);
        std::cout << "Player reached door, switching to Level Complete state for level " << currentLevel << std::endl;
        return;
    }

    for (auto enemy : enemies) {
        if (enemy && enemy->isActive() && CollisionHandler::getInstance()->checkObjectCollision(player, enemy)) {
            Engine::getInstance()->setState(GameStateEnum::GAMEOVER);
            std::cout << "Player collided with enemy, switching to Game Over state\n";
            return;
        }
    }

     auto& playerBullets = player->getBullets();
    float mapWidth = gameMap->getMapWidth() * gameMap->getTileWidth() * gameMap->getScaleFactor();
    float mapHeight = gameMap->getMapHeight() * gameMap->getTileHeight() * gameMap->getScaleFactor();
    for (auto bullet : playerBullets) {
        if (bullet && bullet->isActive()) {
            bullet->update(deltaTime);
            CollisionHandler::getInstance()->checkCollisions(bullet, gameMap, deltaTime);

            float bulletX = bullet->getRigidBody()->position.x;
            float bulletY = bullet->getRigidBody()->position.y;
            if (bulletX < 0 || bulletX > mapWidth || bulletY < 0 || bulletY > mapHeight) {
                bullet->deactivate();
                std::cout << "Bullet deactivated: out of bounds at pos=(" << bulletX << ", " << bulletY << ")\n";
                continue;
            }

            for (auto enemy : enemies) {
                if (enemy && enemy->isActive() && CollisionHandler::getInstance()->checkObjectCollision(bullet, enemy)) {
                    bullet->deactivate();
                    enemy->setActive(false);
                     AudioManager::GetInstance()->PlaySound("assets/audio/die.mp3", 0); // Play enemy death sound
                    std::cout << "Bullet hit enemy at pos=(" << enemy->getRigidBody()->position.x << ", "
                              << enemy->getRigidBody()->position.y << "), enemy deactivated\n";
                    break;
                }
            }
        }
    }
    playerBullets.erase(
        std::remove_if(playerBullets.begin(), playerBullets.end(),
                       [](Bullet* bullet) {
                           bool inactive = !bullet->isActive();
                           if (inactive) delete bullet;
                           return inactive;
                       }),
        playerBullets.end());

    float playerY = player->getRigidBody()->position.y;
    int mapHeightInPixels = gameMap->getMapHeight() * gameMap->getTileHeight() * gameMap->getScaleFactor();
    if (playerY > mapHeightInPixels) {
        Engine::getInstance()->setState(GameStateEnum::GAMEOVER);
    }

    Camera::getInstance()->update();
    elapsedTime = (SDL_GetTicks() - startTime) / 1000.0f;
    updateTimerTexture(Engine::getInstance()->getRenderer());
}
void Play::render(SDL_Renderer* renderer) {
    if (!renderer || !gameMap || !player || !door) return;

    int offsetX = Camera::getInstance()->getOffsetX();
    int offsetY = Camera::getInstance()->getOffsetY();

    gameMap->render(renderer, offsetX, offsetY);
    player->render(renderer);
    door->render(renderer);

    for (auto bullet : player->getBullets()) {
        if (bullet && bullet->isActive()) {
            bullet->render(renderer);
        }
    }

    for (auto enemy : enemies) {
        if (enemy && enemy->isActive()) {
            enemy->render(renderer);
        }
    }

    if (timerTexture) {
        SDL_RenderCopy(renderer, timerTexture, nullptr, &timerRect);
    }
}

void Play::handleEvents(SDL_Event& event) {
    if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE) {
        Engine::getInstance()->setState(GameStateEnum::MENU);
    }
}

void Play::updateTimerTexture(SDL_Renderer* renderer) {
    if (!font || !renderer) return;
    char timeStr[16];
    snprintf(timeStr, sizeof(timeStr), "Time: %.1f", elapsedTime);
    SDL_Surface* surface = TTF_RenderText_Solid(font, timeStr, {255, 255, 255, 255});
    if (surface) {
        if (timerTexture) SDL_DestroyTexture(timerTexture);
        timerTexture = SDL_CreateTextureFromSurface(renderer, surface);
        timerRect.w = surface->w;
        timerRect.h = surface->h;
        SDL_FreeSurface(surface);
    }
}

Play::~Play() {
    AudioManager::GetInstance()->StopMusic();
    if (player) {
        for (auto bullet : player->getBullets()) {
            if (bullet) delete bullet;
        }
        player->getBullets().clear();
        delete player;
        player = nullptr;
    }
    for (auto enemy : enemies) {
        if (enemy) delete enemy;
    }
    enemies.clear();
    if (door) {
        delete door;
        door = nullptr;
    }
    if (timerTexture) {
        SDL_DestroyTexture(timerTexture);
        timerTexture = nullptr;
    }
    if (font) {
        TTF_CloseFont(font);
        font = nullptr;
    }
}
