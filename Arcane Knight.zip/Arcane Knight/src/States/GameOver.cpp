#include "GameOver.h"
#include "Engine.h"
#include "../Graphics/TextureManager.h"
#include "../Audio/AudioManager.h"
#include <iostream>

GameOver::~GameOver() {
    for (auto button : buttons) delete button;
    buttons.clear();
    if (backgroundTexture) SDL_DestroyTexture(backgroundTexture);
    backgroundTexture = nullptr;
    AudioManager::GetInstance()->StopMusic();
}

void GameOver::init() {
    buttons.clear();
    backgroundTexture = TextureManager::getInstance()->loadTexture("assets/gameover.png");
    if (!backgroundTexture) {
        std::cout << "Failed to load gameover background: " << SDL_GetError() << std::endl;
    }

    buttons.push_back(new Button(300, 350, 200, 50, "RETRY", []() {
        Engine::getInstance()->setState(GameStateEnum::PLAYING);
    }));
    buttons.push_back(new Button(300, 450, 200, 50, "MENU", []() {
        Engine::getInstance()->setState(GameStateEnum::MENU);
    }));


    AudioManager::GetInstance()->PlayMusic("assets/audio/gameover.mp3", 0);
}

void GameOver::update(float deltaTime) {
    for (auto button : buttons) {
        button->update();
    }
}

void GameOver::render(SDL_Renderer* renderer) {
    if (!renderer) return;

    if (backgroundTexture) {
        SDL_RenderCopy(renderer, backgroundTexture, nullptr, nullptr);
    } else {
        SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
        SDL_Rect rect = {0, 0, 800, 600};
        SDL_RenderFillRect(renderer, &rect);
    }

    for (auto button : buttons) {
        button->render(renderer);
    }
}

void GameOver::handleEvents(SDL_Event& event) {
    for (auto button : buttons) {
        button->handleEvent(event);
    }
}
