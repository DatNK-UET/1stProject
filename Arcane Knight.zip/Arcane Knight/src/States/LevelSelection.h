// LevelSelection.h
#ifndef LEVELSELECTION_H
#define LEVELSELECTION_H

#include "GameState.h"
#include "Button.h"
#include <vector>
#include <SDL.h>
#include <SDL_ttf.h>

class LevelSelection : public GameState {
public:
    LevelSelection();
    ~LevelSelection() override;
    void init() override;
    void update(float deltaTime) override;
    void render(SDL_Renderer* renderer) override;
    void handleEvents(SDL_Event& event) override;
    void unlockLevel(int level);

private:
    void updateTitleTexture(SDL_Renderer* renderer);

    std::vector<Button*> buttons;
    TTF_Font* font;
    SDL_Texture* titleTexture;
    SDL_Rect titleRect;
    bool level2Unlocked;
    bool level3Unlocked;
};

#endif
