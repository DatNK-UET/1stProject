#ifndef GAMEOVER_H
#define GAMEOVER_H

#include "GameState.h"
#include "Button.h"
#include <vector>
#include <SDL.h>

class GameOver : public GameState {
public:
    GameOver() : backgroundTexture(nullptr) {}
    ~GameOver() override;
    void init() override;
    void update(float deltaTime) override;
    void render(SDL_Renderer* renderer) override;
    void handleEvents(SDL_Event& event) override;

private:
    std::vector<Button*> buttons;
    SDL_Texture* backgroundTexture;
};

#endif
