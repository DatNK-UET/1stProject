#ifndef GAMESTATE_H
#define GAMESTATE_H

#include <SDL.h>

class GameState {
public:
    virtual void init() = 0;
    virtual void update(float deltaTime) = 0;
    virtual void render(SDL_Renderer* renderer) = 0;
    virtual void handleEvents(SDL_Event& event) = 0;
    virtual ~GameState() {}
};

#endif
