#include "LevelComplete.h"
#include "Engine.h"
#include "Play.h"
#include <sstream>
#include <iostream>
#include "LevelSelection.h"

LevelComplete::LevelComplete() : font(nullptr), titleTexture(nullptr), completedLevel(1) {}

LevelComplete::~LevelComplete() {
    for (auto button : buttons) delete button;
    buttons.clear();
    if (titleTexture) SDL_DestroyTexture(titleTexture);
    titleTexture = nullptr;
    if (font) TTF_CloseFont(font);
    font = nullptr;
}

void LevelComplete::setLevel(int level) {
    completedLevel = level;
}

void LevelComplete::init() {

    for (auto button : buttons) delete button;
    buttons.clear();


    if (titleTexture) SDL_DestroyTexture(titleTexture);
    titleTexture = nullptr;
    if (font) TTF_CloseFont(font);
    font = nullptr;


    auto levelSelection = dynamic_cast<LevelSelection*>(Engine::getInstance()->getState(GameStateEnum::LEVEL_SELECTION));


    if (completedLevel == 1) {
        if (levelSelection) levelSelection->unlockLevel(2); // Mở khóa màn 2
        buttons.push_back(new Button(300, 300, 200, 50, "LEVEL 2", []() {
            auto play = dynamic_cast<Play*>(Engine::getInstance()->getState(GameStateEnum::PLAYING));
            if (play) play->setLevel(2);
            Engine::getInstance()->setState(GameStateEnum::PLAYING);
        }));
    } else if (completedLevel == 2) {
        if (levelSelection) levelSelection->unlockLevel(3); // Mở khóa màn 3
        buttons.push_back(new Button(300, 300, 200, 50, "LEVEL 3", []() {
            auto play = dynamic_cast<Play*>(Engine::getInstance()->getState(GameStateEnum::PLAYING));
            if (play) play->setLevel(3);
            Engine::getInstance()->setState(GameStateEnum::PLAYING);
        }));
    }
    buttons.push_back(new Button(300, 400, 200, 50, "MENU", []() {
        Engine::getInstance()->setState(GameStateEnum::MENU);
    }));


    font = TTF_OpenFont("assets/arial.ttf", 36);
    if (!font) {
        std::cout << "Failed to load font: " << TTF_GetError() << std::endl;
        return;
    }
    titleRect = {200, 100, 400, 50};
    updateTitleTexture(Engine::getInstance()->getRenderer());
}

void LevelComplete::updateTitleTexture(SDL_Renderer* renderer) {
    if (!font || !renderer) return;
    std::string title = " Complete!";
    SDL_Surface* surface = TTF_RenderText_Solid(font, title.c_str(), {255, 255, 255, 255});
    if (surface) {
        if (titleTexture) SDL_DestroyTexture(titleTexture);
        titleTexture = SDL_CreateTextureFromSurface(renderer, surface);
        titleRect.w = surface->w;
        titleRect.h = surface->h;
        SDL_FreeSurface(surface);
    } else {
        std::cout << "Failed to render text: " << TTF_GetError() << std::endl;
    }
}

void LevelComplete::update(float deltaTime) {
    for (auto button : buttons) {
        button->update();
    }
}

void LevelComplete::render(SDL_Renderer* renderer) {
    if (!renderer) return;
    SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
    SDL_Rect rect = {0, 0, 800, 600};
    SDL_RenderFillRect(renderer, &rect);

    if (titleTexture) {
        SDL_RenderCopy(renderer, titleTexture, nullptr, &titleRect);
    }

    for (auto button : buttons) {
        button->render(renderer);
    }
}

void LevelComplete::handleEvents(SDL_Event& event) {
    for (auto button : buttons) {
        button->handleEvent(event);
    }
}
