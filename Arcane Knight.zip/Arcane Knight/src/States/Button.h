#ifndef BUTTON_H
#define BUTTON_H

#include <SDL.h>
#include <SDL_ttf.h>
#include <functional>
#include <string>

class Button {
public:
    Button(int x, int y, int w, int h, const std::string& text, std::function<void()> onClick);
    ~Button();
    void update();
    void render(SDL_Renderer* renderer);
    bool handleEvent(SDL_Event& event);

private:
    SDL_Rect rect;
    std::string text;
    std::function<void()> onClick;
    TTF_Font* font;
    SDL_Texture* textTexture;
    SDL_Rect textRect;
    bool isHovered;
    void updateTextTexture(SDL_Renderer* renderer);
};

#endif
