#ifndef PLAY_H
#define PLAY_H

#include "GameState.h"
#include "GameMap.h"
#include "Warrior.h"
#include "Bullet.h"
#include "Enemy.h"
#include "Door.h"
#include "LevelComplete.h"
#include <SDL_ttf.h>
#include <vector>

class Play : public GameState {
public:
    Play();
    ~Play();
    void init() override;
    void update(float deltaTime) override;
    void render(SDL_Renderer* renderer) override;
    void handleEvents(SDL_Event& event) override;
    void setLevel(int level);
    void spawnEnemies();

private:
    void updateTimerTexture(SDL_Renderer* renderer);

    GameMap* gameMap;
    Warrior* player;
    std::vector<Enemy*> enemies;
    Door* door;
    TTF_Font* font;
    SDL_Texture* timerTexture;
    SDL_Rect timerRect;
    Uint32 startTime;
    float elapsedTime;
    float bulletCooldown;
    float lastShotTime;
    int currentLevel;
};

#endif
