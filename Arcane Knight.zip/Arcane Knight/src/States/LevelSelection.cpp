
#include "LevelSelection.h"
#include "Engine.h"
#include "Play.h"
#include <sstream>

LevelSelection::LevelSelection() : font(nullptr), titleTexture(nullptr), level2Unlocked(false), level3Unlocked(false) {}

LevelSelection::~LevelSelection() {
    for (auto button : buttons) delete button;
    buttons.clear();
    if (titleTexture) SDL_DestroyTexture(titleTexture);
    if (font) TTF_CloseFont(font);
}


void LevelSelection::init() {
    buttons.clear();

    buttons.push_back(new Button(300, 200, 200, 50, "LEVEL 1", []() {
        auto play = dynamic_cast<Play*>(Engine::getInstance()->getState(GameStateEnum::PLAYING));
        if (play) play->setLevel(1);
        Engine::getInstance()->setState(GameStateEnum::PLAYING);
    }));

    buttons.push_back(new Button(300, 300, 200, 50, level2Unlocked ? "LEVEL 2" : "LEVEL 2 (Locked)", [this]() {
        if (level2Unlocked) {
            auto play = dynamic_cast<Play*>(Engine::getInstance()->getState(GameStateEnum::PLAYING));
            if (play) play->setLevel(2);
            Engine::getInstance()->setState(GameStateEnum::PLAYING);
        }
    }));

    buttons.push_back(new Button(300, 400, 200, 50, level3Unlocked ? "LEVEL 3" : "LEVEL 3 (Locked)", [this]() {
        if (level3Unlocked) {
            auto play = dynamic_cast<Play*>(Engine::getInstance()->getState(GameStateEnum::PLAYING));
            if (play) play->setLevel(3);
            Engine::getInstance()->setState(GameStateEnum::PLAYING);
        }
    }));

    buttons.push_back(new Button(300, 500, 200, 50, "MENU", []() {
        Engine::getInstance()->setState(GameStateEnum::MENU);
    }));

    font = TTF_OpenFont("assets/arial.ttf", 36);
    titleRect = { 200, 100, 400, 50 };
    updateTitleTexture(Engine::getInstance()->getRenderer());
}

void LevelSelection::update(float deltaTime) {
    for (auto button : buttons) {
        button->update();
    }
}

void LevelSelection::render(SDL_Renderer* renderer) {
    if (!renderer) return;

    SDL_SetRenderDrawColor(renderer, 0, 200, 255, 255);
    SDL_Rect rect = {0, 0, 800, 600};
    SDL_RenderFillRect(renderer, &rect);


    if (titleTexture) {
        SDL_RenderCopy(renderer, titleTexture, nullptr, &titleRect);
    }


    for (auto button : buttons) {
        button->render(renderer);
    }
}

void LevelSelection::handleEvents(SDL_Event& event) {
    for (auto button : buttons) {
        button->handleEvent(event);
    }
}

void LevelSelection::updateTitleTexture(SDL_Renderer* renderer) {
    if (!font || !renderer) return;
    std::string title = "Select Level";
    SDL_Surface* surface = TTF_RenderText_Solid(font, title.c_str(), {255, 255, 255, 255});
    if (surface) {
        if (titleTexture) SDL_DestroyTexture(titleTexture);
        titleTexture = SDL_CreateTextureFromSurface(renderer, surface);
        titleRect.w = surface->w;
        titleRect.h = surface->h;
        SDL_FreeSurface(surface);
    }
}

void LevelSelection::unlockLevel(int level) {
    if (level == 2) {
        level2Unlocked = true;
        if (!buttons.empty() && buttons.size() > 1) {
            delete buttons[1];
            buttons[1] = new Button(300, 300, 200, 50, "LEVEL 2", [this]() {
                auto play = dynamic_cast<Play*>(Engine::getInstance()->getState(GameStateEnum::PLAYING));
                if (play) play->setLevel(2);
                Engine::getInstance()->setState(GameStateEnum::PLAYING);
            });
        }
    } else if (level == 3) {
        level3Unlocked = true;
        if (!buttons.empty() && buttons.size() > 2) {
            delete buttons[2];
            buttons[2] = new Button(300, 400, 200, 50, "LEVEL 3", [this]() {
                auto play = dynamic_cast<Play*>(Engine::getInstance()->getState(GameStateEnum::PLAYING));
                if (play) play->setLevel(3);
                Engine::getInstance()->setState(GameStateEnum::PLAYING);
            });
        }
    }
}
