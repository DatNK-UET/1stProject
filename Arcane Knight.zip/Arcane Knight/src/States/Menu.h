#ifndef MENU_H
#define MENU_H

#include "GameState.h"
#include "Button.h"
#include <vector>
#include <SDL.h>

class Menu : public GameState {
public:
    Menu() {}
    ~Menu() override;
    void init() override;
    void update(float deltaTime) override;
    void render(SDL_Renderer* renderer) override;
    void handleEvents(SDL_Event& event) override;
    SDL_Texture* backgroundTexture;

private:
    std::vector<Button*> buttons;
};

#endif
