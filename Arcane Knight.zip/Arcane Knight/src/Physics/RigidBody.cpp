#include "RigidBody.h"
#include <iostream>
#include <cmath>

void RigidBody::update(float deltaTime) {

    velocity += acceleration * deltaTime;

    position += velocity * deltaTime;


}
