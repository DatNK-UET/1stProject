#ifndef RIGIDBODY_H
#define RIGIDBODY_H

#include "Vector2D.h"

class RigidBody {
public:
    RigidBody() : position(0.0f, 0.0f), velocity(0.0f, 0.0f), acceleration(0.0f, 0.0f) {}
    void update(float deltaTime);

    Vector2D position;
    Vector2D velocity;
    Vector2D acceleration;
};

#endif
