#ifndef VECTOR2D_H
#define VECTOR2D_H

class Vector2D {
public:
    Vector2D() : x(0.0f), y(0.0f) {}
    Vector2D(float x, float y) : x(x), y(y) {}
    Vector2D(const Vector2D& other) = default;
    Vector2D(Vector2D&& other) = default;


    Vector2D& operator=(const Vector2D& other) {
        if (this != &other) {
            x = other.x;
            y = other.y;
        }
        return *this;
    }

    Vector2D& operator+=(const Vector2D& other) {
        x += other.x;
        y += other.y;
        return *this;
    }

    Vector2D operator*(float scalar) const {
        return Vector2D(x * scalar, y * scalar);
    }

    float x, y;
};

inline Vector2D operator*(float scalar, const Vector2D& vec) {
    return vec * scalar;
}

#endif
