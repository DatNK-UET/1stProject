#include "ObjectFactory.h"
#include "../Characters/Warrior.h"
#include "../Characters/Enemy.h"
#include "../Characters/Door.h"

ObjectFactory* ObjectFactory::instance = nullptr;

ObjectFactory* ObjectFactory::getInstance() {
    if (!instance) instance = new ObjectFactory();
    return instance;
}

void ObjectFactory::registerType(const std::string& type, std::function<GameObject*()> creator) {
    creators[type] = creator;
}

GameObject* ObjectFactory::createObject(const std::string& type) {
    auto it = creators.find(type);
    if (it != creators.end()) {
        return it->second();
    }
    return nullptr;
}

namespace {
    bool initializeFactory() {
        ObjectFactory* factory = ObjectFactory::getInstance();
        factory->registerType("Warrior", []() -> GameObject* { return new Warrior(); });
        factory->registerType("Enemy", []() -> GameObject* { return new Enemy(); });
        factory->registerType("Door", []() -> GameObject* { return new Door(0, 0, 32, 32); });
        return true;
    }
    bool initialized = initializeFactory();
}
