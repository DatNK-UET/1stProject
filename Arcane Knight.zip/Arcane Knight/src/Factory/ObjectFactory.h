#ifndef OBJECTFACTORY_H
#define OBJECTFACTORY_H

#include <string>
#include <map>
#include <functional>
#include "GameObject.h"

class ObjectFactory {
private:
    static ObjectFactory* instance;
    std::map<std::string, std::function<GameObject*()>> creators;

public:
    static ObjectFactory* getInstance();
    void registerType(const std::string& type, std::function<GameObject*()> creator);
    GameObject* createObject(const std::string& type);
};

#endif
