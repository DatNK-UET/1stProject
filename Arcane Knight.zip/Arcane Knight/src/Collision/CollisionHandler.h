#ifndef COLLISIONHANDLER_H
#define COLLISIONHANDLER_H

#include "../Characters/Warrior.h"
#include "../Characters/Bullet.h"
#include "../Characters/Enemy.h"
#include "../Map/GameMap.h"

class CollisionHandler {
public:
    static CollisionHandler* getInstance();
    void checkCollisions(Warrior* player, GameMap* gameMap, float deltaTime);
    void checkCollisions(Enemy* enemy, GameMap* gameMap, float deltaTime);
    void checkCollisions(Bullet* bullet, GameMap* gameMap, float deltaTime);
    bool checkObjectCollision(GameObject* obj1, GameObject* obj2);

private:
    CollisionHandler() {}
    static CollisionHandler* instance;
    bool isCollidingAtPosition(float x, float y, Warrior* player, GameMap* gameMap);
    bool isCollidingAtPosition(float x, float y, Enemy* enemy, GameMap* gameMap);
    bool isCollidingAtPosition(float x, float y, Bullet* bullet, GameMap* gameMap);
    bool checkGround(Warrior* player, GameMap* gameMap, float tolerance = 0.0f);
    bool checkGround(Enemy* enemy, GameMap* gameMap, float tolerance = 0.0f);
};

#endif
