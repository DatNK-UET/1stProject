#include "CollisionHandler.h"
#include "Warrior.h"
#include "Bullet.h"
#include "Enemy.h"
#include "GameMap.h"
#include <algorithm>
#include <cmath>
#include <iostream>

CollisionHandler* CollisionHandler::instance = nullptr;

CollisionHandler* CollisionHandler::getInstance() {
    if (!instance) instance = new CollisionHandler();
    return instance;
}

bool CollisionHandler::isCollidingAtPosition(float x, float y, Warrior* player, GameMap* gameMap) {
    float scaledTileSize = gameMap->getTileWidth() * gameMap->getScaleFactor();
    int startTileX = std::max(0, static_cast<int>(std::floor(x / scaledTileSize)));
    int endTileX = std::min(gameMap->getMapWidth() - 1, static_cast<int>(std::floor((x + player->getWidth()) / scaledTileSize)));
    int startTileY = std::max(0, static_cast<int>(std::floor(y / scaledTileSize)));
    int endTileY = std::min(gameMap->getMapHeight() - 1, static_cast<int>(std::floor((y + player->getHeight()) / scaledTileSize)));

    for (int tileY = startTileY; tileY <= endTileY; ++tileY) {
        for (int tileX = startTileX; tileX <= endTileX; ++tileX) {
            if (gameMap->isTileSolid(tileX, tileY)) {
                float tileLeft = tileX * scaledTileSize;
                float tileRight = tileLeft + scaledTileSize;
                float tileTop = tileY * scaledTileSize;
                float tileBottom = tileTop + scaledTileSize;

                if (x + player->getWidth() > tileLeft && x < tileRight &&
                    y + player->getHeight() > tileTop && y < tileBottom) {
                    return true;
                }
            }
        }
    }
    return false;
}

bool CollisionHandler::isCollidingAtPosition(float x, float y, Enemy* enemy, GameMap* gameMap) {
    float scaledTileSize = gameMap->getTileWidth() * gameMap->getScaleFactor();
    int startTileX = std::max(0, static_cast<int>(std::floor((x - scaledTileSize) / scaledTileSize)));
    int endTileX = std::min(gameMap->getMapWidth() - 1, static_cast<int>(std::floor((x + enemy->getWidth() + scaledTileSize) / scaledTileSize)));
    int startTileY = std::max(0, static_cast<int>(std::floor((y - scaledTileSize) / scaledTileSize)));
    int endTileY = std::min(gameMap->getMapHeight() - 1, static_cast<int>(std::floor((y + enemy->getHeight() + scaledTileSize) / scaledTileSize)));

    for (int y = startTileY; y <= endTileY; ++y) {
        for (int x = startTileX; x <= endTileX; ++x) {
            if (!gameMap->isTileSolid(x, y)) continue;

            float tileLeft = x * scaledTileSize;
            float tileRight = tileLeft + scaledTileSize;
            float tileTop = y * scaledTileSize;
            float tileBottom = tileTop + scaledTileSize;

            if (x + enemy->getWidth() > tileLeft && x < tileRight &&
                y + enemy->getHeight() > tileTop && y < tileBottom) {
                return true;
            }
        }
    }
    return false;
}


bool CollisionHandler::isCollidingAtPosition(float x, float y, Bullet* bullet, GameMap* gameMap) {
    float scaledTileSize = gameMap->getTileWidth() * gameMap->getScaleFactor();
    int startTileX = std::max(0, static_cast<int>(std::floor((x - scaledTileSize) / scaledTileSize)));
    int endTileX = std::min(gameMap->getMapWidth() - 1, static_cast<int>(std::floor((x + bullet->getWidth() + scaledTileSize) / scaledTileSize)));
    int startTileY = std::max(0, static_cast<int>(std::floor((y - scaledTileSize) / scaledTileSize)));
    int endTileY = std::min(gameMap->getMapHeight() - 1, static_cast<int>(std::floor((y + bullet->getHeight() + scaledTileSize) / scaledTileSize)));

    for (int y = startTileY; y <= endTileY; ++y) {
        for (int x = startTileX; x <= endTileX; ++x) {
            if (!gameMap->isTileSolid(x, y)) continue;

            float tileLeft = x * scaledTileSize;
            float tileRight = tileLeft + scaledTileSize;
            float tileTop = y * scaledTileSize;
            float tileBottom = tileTop + scaledTileSize;

            if (x + bullet->getWidth() > tileLeft && x < tileRight &&
                y + bullet->getHeight() > tileTop && y < tileBottom) {
                return true;
            }
        }
    }
    return false;
}


bool CollisionHandler::checkGround(Warrior* player, GameMap* gameMap, float tolerance) {
    RigidBody* rb = player->getRigidBody();
    float scaledTileSize = gameMap->getTileWidth() * gameMap->getScaleFactor();

    float checkY = rb->position.y + player->getHeight();
    float checkYEnd = checkY + tolerance;

    int startTileX = std::max(0, static_cast<int>(std::floor(rb->position.x / scaledTileSize)));
    int endTileX = std::min(gameMap->getMapWidth() - 1, static_cast<int>(std::floor((rb->position.x + player->getWidth()) / scaledTileSize)));

    float closestTileTop = std::numeric_limits<float>::infinity();
    bool isOnGround = false;


    for (float yPos = checkY; yPos <= checkYEnd; yPos += 0.01f) {
        int tileY = static_cast<int>(std::floor(yPos / scaledTileSize));
        if (tileY >= gameMap->getMapHeight()) continue;

        for (int x = startTileX; x <= endTileX; ++x) {
            if (gameMap->isTileSolid(x, tileY)) {
                float tileTop = tileY * scaledTileSize;

                if (yPos >= tileTop && yPos <= tileTop + scaledTileSize &&
                    (rb->position.y + player->getHeight()) <= tileTop + tolerance) {
                    isOnGround = true;
                    closestTileTop = std::min(closestTileTop, tileTop);
                }
            }
        }
    }


    if (isOnGround && closestTileTop != std::numeric_limits<float>::infinity() && rb->velocity.y >= 0) {
        float targetY = closestTileTop - player->getHeight();
        rb->position.y = targetY;
        rb->velocity.y = 0.0f;
        rb->acceleration.y = 0.0f;
        std::cout << "Ground detected: Adjusted posY to " << rb->position.y << ", tileTop = " << closestTileTop << "\n";
    }


    std::cout << "checkGround: onGround=" << isOnGround
              << ", posY=" << rb->position.y
              << ", height=" << player->getHeight()
              << ", checkY=" << checkY
              << ", checkYEnd=" << checkYEnd
              << ", closestTileTop=" << closestTileTop
              << ", scaledTileSize=" << scaledTileSize
              << ", startTileX=" << startTileX
              << ", endTileX=" << endTileX << "\n";

    return isOnGround;
}

bool CollisionHandler::checkGround(Enemy* enemy, GameMap* gameMap, float tolerance) {
    RigidBody* rb = enemy->getRigidBody();
    float scaledTileSize = gameMap->getTileWidth() * gameMap->getScaleFactor();
    float checkY = rb->position.y + enemy->getHeight() - tolerance;
    float checkYEnd = checkY + scaledTileSize * 0.5f;
    int startTileX = std::max(0, static_cast<int>(std::floor((rb->position.x + 4.0f) / scaledTileSize)));
    int endTileX = std::min(gameMap->getMapWidth() - 1, static_cast<int>(std::floor((rb->position.x + enemy->getWidth() - 4.0f) / scaledTileSize)));

    float closestTileTop = -1.0f;
    bool isOnGround = false;

    for (float yPos = checkY; yPos <= checkYEnd; yPos += 1.0f) {
        int tileY = static_cast<int>(std::floor(yPos / scaledTileSize));
        if (tileY >= gameMap->getMapHeight()) continue;

        for (int x = startTileX; x <= endTileX; ++x) {
            if (gameMap->isTileSolid(x, tileY)) {
                float tileTop = tileY * scaledTileSize;
                if (yPos >= tileTop && yPos <= tileTop + scaledTileSize &&
                    std::abs((rb->position.y + enemy->getHeight()) - tileTop) < tolerance * 2.0f) {
                    isOnGround = true;
                    if (closestTileTop < 0 || tileTop > closestTileTop) {
                        closestTileTop = tileTop;
                    }
                }
            }
        }
    }

    if (isOnGround && closestTileTop >= 0 && rb->velocity.y >= 0) {
        float targetY = closestTileTop - enemy->getHeight();
        if (std::abs(rb->position.y - targetY) > 0.01f) {
            rb->position.y = targetY;
            std::cout << "Enemy adjusted posY to " << rb->position.y << " to align with tileTop " << closestTileTop << "\n";
        }
    }

    return isOnGround;
}


void CollisionHandler::checkCollisions(Warrior* player, GameMap* gameMap, float deltaTime) {
    if (!player || !gameMap || !player->getRigidBody()) return;

    RigidBody* rb = player->getRigidBody();
    float scaledTileSize = gameMap->getTileWidth() * gameMap->getScaleFactor();
    float groundTolerance = scaledTileSize * 0.2f;
    float velocityThreshold = 0.01f;
    float epsilon = scaledTileSize * 0.01f;


    deltaTime = std::min(deltaTime, 1.0f / 60.0f);


    const float maxHorizontalVelocity = 200.0f;
    rb->velocity.x = std::max(-maxHorizontalVelocity, std::min(maxHorizontalVelocity, rb->velocity.x));
    const float maxVerticalVelocity = 758.9f;
    rb->velocity.y = std::max(-maxVerticalVelocity, std::min(maxVerticalVelocity, rb->velocity.y));


    if (!player->isOnGround()) {
        rb->acceleration.y = 1500.0f;
        rb->velocity.y += rb->acceleration.y * deltaTime;
    } else {
        rb->acceleration.y = 0.0f;
        rb->velocity.y = 0.0f;
    }

    float oldX = rb->position.x;
    float oldY = rb->position.y;
    float totalDX = rb->velocity.x * deltaTime;
    float totalDY = rb->velocity.y * deltaTime;


    float maxVelocity = std::max(std::abs(rb->velocity.x), std::abs(rb->velocity.y));
    int steps = std::min(30, std::max(1, static_cast<int>(std::ceil(maxVelocity * deltaTime / (scaledTileSize * 0.02f)))));

    for (int i = 0; i < steps; ++i) {
        float stepDX = totalDX / steps;
        float stepDY = totalDY / steps;
        float newX = rb->position.x + stepDX;
        float newY = rb->position.y + stepDY;

        bool xCollision = false, yCollision = false;


        if (isCollidingAtPosition(newX, newY, player, gameMap)) {

            if (std::abs(stepDX) > velocityThreshold && isCollidingAtPosition(newX, rb->position.y, player, gameMap)) {
                xCollision = true;
                int startTileX = std::max(0, static_cast<int>(std::floor(std::min(rb->position.x, newX) / scaledTileSize)));
                int endTileX = std::min(gameMap->getMapWidth() - 1, static_cast<int>(std::floor((std::max(rb->position.x, newX) + player->getWidth()) / scaledTileSize)));
                int startTileY = std::max(0, static_cast<int>(std::floor(rb->position.y / scaledTileSize)));
                int endTileY = std::min(gameMap->getMapHeight() - 1, static_cast<int>(std::floor((rb->position.y + player->getHeight()) / scaledTileSize)));

                float closestX = rb->position.x;
                if (rb->velocity.x > 0) {
                    float minTileLeft = std::numeric_limits<float>::infinity();
                    for (int y = startTileY; y <= endTileY; ++y) {
                        for (int x = startTileX; x <= endTileX; ++x) {
                            if (gameMap->isTileSolid(x, y)) {
                                float tileLeft = x * scaledTileSize;
                                if (rb->position.y + player->getHeight() > y * scaledTileSize &&
                                    rb->position.y < (y + 1) * scaledTileSize) {
                                    minTileLeft = std::min(minTileLeft, tileLeft);
                                }
                            }
                        }
                    }
                    if (minTileLeft != std::numeric_limits<float>::infinity()) {
                        closestX = minTileLeft - player->getWidth() - epsilon;
                    }
                } else if (rb->velocity.x < 0) {
                    float maxTileRight = -std::numeric_limits<float>::infinity();
                    for (int y = startTileY; y <= endTileY; ++y) {
                        for (int x = startTileX; x <= endTileX; ++x) {
                            if (gameMap->isTileSolid(x, y)) {
                                float tileRight = (x + 1) * scaledTileSize;
                                if (rb->position.y + player->getHeight() > y * scaledTileSize &&
                                    rb->position.y < (y + 1) * scaledTileSize) {
                                    maxTileRight = std::max(maxTileRight, tileRight);
                                }
                            }
                        }
                    }
                    if (maxTileRight != -std::numeric_limits<float>::infinity()) {
                        closestX = maxTileRight + epsilon;
                    }
                }
                rb->position.x = closestX;
                rb->velocity.x = 0.0f;
                newX = rb->position.x;
            }


            if (std::abs(stepDY) > velocityThreshold && isCollidingAtPosition(rb->position.x, newY, player, gameMap)) {
                yCollision = true;
                int startTileX = std::max(0, static_cast<int>(std::floor(rb->position.x / scaledTileSize)));
                int endTileX = std::min(gameMap->getMapWidth() - 1, static_cast<int>(std::floor((rb->position.x + player->getWidth()) / scaledTileSize)));
                int startTileY = std::max(0, static_cast<int>(std::floor(std::min(rb->position.y, newY) / scaledTileSize)));
                int endTileY = std::min(gameMap->getMapHeight() - 1, static_cast<int>(std::floor((std::max(rb->position.y, newY) + player->getHeight()) / scaledTileSize)));

                float closestY = rb->position.y;
                if (rb->velocity.y > 0) {

                    float minTileTop = std::numeric_limits<float>::infinity();
                    for (int y = startTileY; y <= endTileY; ++y) {
                        for (int x = startTileX; x <= endTileX; ++x) {
                            if (gameMap->isTileSolid(x, y)) {
                                float tileTop = y * scaledTileSize;
                                if (rb->position.x + player->getWidth() > x * scaledTileSize &&
                                    rb->position.x < (x + 1) * scaledTileSize) {
                                    minTileTop = std::min(minTileTop, tileTop);
                                }
                            }
                        }
                    }
                    if (minTileTop != std::numeric_limits<float>::infinity()) {
                        closestY = minTileTop - player->getHeight() - epsilon;
                    }
                } else if (rb->velocity.y < 0) {

                    float maxTileBottom = -std::numeric_limits<float>::infinity();
                    for (int y = startTileY; y <= endTileY; ++y) {
                        for (int x = startTileX; x <= endTileX; ++x) {
                            if (gameMap->isTileSolid(x, y)) {
                                float tileBottom = (y + 1) * scaledTileSize;
                                if (rb->position.x + player->getWidth() > x * scaledTileSize &&
                                    rb->position.x < (x + 1) * scaledTileSize) {
                                    maxTileBottom = std::max(maxTileBottom, tileBottom);
                                }
                            }
                        }
                    }
                    if (maxTileBottom != -std::numeric_limits<float>::infinity()) {
                        closestY = maxTileBottom + epsilon;
                    }
                }
                rb->position.y = closestY;
                rb->velocity.y = 0.0f;
                rb->acceleration.y = 0.0f;
                newY = rb->position.y;
            }

            if (xCollision && yCollision) {
                rb->velocity.x = 0.0f;
                rb->velocity.y = 0.0f;
                rb->acceleration.y = 0.0f;
                continue;
            }
        }


        if (!xCollision) rb->position.x = newX;
        if (!yCollision) rb->position.y = newY;


        if (isCollidingAtPosition(rb->position.x, rb->position.y, player, gameMap)) {
            rb->position.x = oldX;
            rb->position.y = oldY;
            rb->velocity.x = 0.0f;
            rb->velocity.y = 0.0f;
            rb->acceleration.y = 0.0f;
            std::cout << "Invalid position detected, reverted to (" << oldX << ", " << oldY << ")\n";
            break;
        }
    }

    bool onGround = checkGround(player, gameMap, groundTolerance);
    player->setOnGround(onGround);
    if (!onGround) {
        rb->acceleration.y = 5000.0f;
    } else {
        rb->velocity.y = 0.0f;
        rb->acceleration.y = 0.0f;
    }


    float maxX = gameMap->getMapWidth() * scaledTileSize - player->getWidth();
    float maxY = gameMap->getMapHeight() * scaledTileSize - player->getHeight();
    rb->position.x = std::max(0.0f, std::min(rb->position.x, maxX));
    rb->position.y = std::max(0.0f, std::min(rb->position.y, maxY));


    std::cout << "Player pos=(" << rb->position.x << ", " << rb->position.y << "), vel=(" << rb->velocity.x << ", " << rb->velocity.y << "), acc=(" << rb->acceleration.x << ", " << rb->acceleration.y << "), onGround=" << onGround << "\n";
}


void CollisionHandler::checkCollisions(Enemy* enemy, GameMap* gameMap, float deltaTime) {
    if (!enemy || !gameMap || !enemy->getRigidBody()) return;

    RigidBody* rb = enemy->getRigidBody();
    float tileSize = gameMap->getTileWidth();
    float scaleFactor = gameMap->getScaleFactor();
    float scaledTileSize = tileSize * scaleFactor;
    bool onGround = enemy->isOnGround();
    float groundTolerance = scaledTileSize * 0.1f;
    float velocityThreshold = 0.01f;

    deltaTime = std::min(deltaTime, 1.0f / 240.0f);

    if (onGround && std::abs(rb->velocity.x) < velocityThreshold && std::abs(rb->velocity.y) < velocityThreshold) {
        onGround = checkGround(enemy, gameMap, groundTolerance);
        enemy->setOnGround(onGround);
        if (!onGround) {
            rb->acceleration.y = 1600.0f;
        } else {
            rb->velocity.y = 0.0f;
            rb->acceleration.y = 0.0f;
        }
        rb->update(deltaTime);
        return;
    }

    float totalDX = rb->velocity.x * deltaTime;
    float totalDY = rb->velocity.y * deltaTime;

    float maxVelocity = std::max(std::abs(rb->velocity.x), std::abs(rb->velocity.y));
    int steps = std::max(1, static_cast<int>(std::ceil(maxVelocity * deltaTime / (scaledTileSize * 0.1f))));

    for (int i = 0; i < steps; ++i) {
        float stepDX = totalDX / steps;
        float stepDY = totalDY / steps;

        float oldX = rb->position.x;
        float oldY = rb->position.y;

        float newX = oldX + stepDX;
        float newY = oldY + stepDY;

        float epsilon = scaledTileSize * 0.02f;

        bool yCollision = false;
        if (std::abs(rb->velocity.y) > velocityThreshold) {
            rb->position.y = newY;
            int startTileX = std::max(0, static_cast<int>(std::floor((rb->position.x - scaledTileSize) / scaledTileSize)));
            int endTileX = std::min(gameMap->getMapWidth() - 1, static_cast<int>(std::floor((rb->position.x + enemy->getWidth() + scaledTileSize) / scaledTileSize)));
            int startTileY = std::max(0, static_cast<int>(std::floor((std::min(oldY, newY) - scaledTileSize * 2) / scaledTileSize)));
            int endTileY = std::min(gameMap->getMapHeight() - 1, static_cast<int>(std::floor((std::max(oldY, newY) + enemy->getHeight() + scaledTileSize * 2) / scaledTileSize)));

            for (int y = startTileY; y <= endTileY; ++y) {
                for (int x = startTileX; x <= endTileX; ++x) {
                    if (!gameMap->isTileSolid(x, y)) continue;

                    float tileLeft = x * scaledTileSize;
                    float tileRight = tileLeft + scaledTileSize;
                    float tileTop = y * scaledTileSize;
                    float tileBottom = tileTop + scaledTileSize;

                    if (rb->velocity.y > 0 && newY + enemy->getHeight() > tileTop &&
                        oldY + enemy->getHeight() <= tileTop + epsilon &&
                        rb->position.x + enemy->getWidth() > tileLeft && rb->position.x < tileRight) {
                        rb->position.y = tileTop - enemy->getHeight() - epsilon;
                        rb->velocity.y = 0;
                        rb->acceleration.y = 0;
                        onGround = true;
                        yCollision = true;
                    }
                    else if (rb->velocity.y < 0 && newY < tileBottom &&
                             oldY >= tileBottom - epsilon &&
                             rb->position.x + enemy->getWidth() > tileLeft && rb->position.x < tileRight) {
                        rb->position.y = tileBottom + epsilon;
                        rb->velocity.y = 0;
                        yCollision = true;
                    }
                }
                if (yCollision) break;
            }

            if (yCollision && isCollidingAtPosition(rb->position.x, rb->position.y, enemy, gameMap)) {
                rb->position.y = oldY;
                rb->velocity.y = 0;
                rb->acceleration.y = 0;
                onGround = checkGround(enemy, gameMap, groundTolerance);
            }
        }

        bool xCollision = false;
        if (std::abs(rb->velocity.x) > velocityThreshold && !yCollision) {
            rb->position.x = newX;
            int startTileX = std::max(0, static_cast<int>(std::floor((std::min(oldX, newX) - scaledTileSize) / scaledTileSize)));
            int endTileX = std::min(gameMap->getMapWidth() - 1, static_cast<int>(std::floor((std::max(oldX, newX) + enemy->getWidth() + scaledTileSize) / scaledTileSize)));
            int startTileY = std::max(0, static_cast<int>(std::floor((rb->position.y - scaledTileSize) / scaledTileSize)));
            int endTileY = std::min(gameMap->getMapHeight() - 1, static_cast<int>(std::floor((rb->position.y + enemy->getHeight() + scaledTileSize) / scaledTileSize)));

            for (int y = startTileY; y <= endTileY; ++y) {
                for (int x = startTileX; x <= endTileX; ++x) {
                    if (!gameMap->isTileSolid(x, y)) continue;

                    float tileLeft = x * scaledTileSize;
                    float tileRight = tileLeft + scaledTileSize;
                    float tileTop = y * scaledTileSize;
                    float tileBottom = tileTop + scaledTileSize;

                    if (rb->velocity.x > 0 && newX + enemy->getWidth() > tileLeft &&
                        oldX + enemy->getWidth() <= tileLeft + epsilon &&
                        rb->position.y + enemy->getHeight() > tileTop && rb->position.y < tileBottom) {
                        rb->position.x = tileLeft - enemy->getWidth() - epsilon;
                        rb->velocity.x = 0;
                        xCollision = true;
                    }
                    else if (rb->velocity.x < 0 && newX < tileRight &&
                             oldX >= tileRight - epsilon &&
                             rb->position.y + enemy->getHeight() > tileTop && rb->position.y < tileBottom) {
                        rb->position.x = tileRight + epsilon;
                        rb->velocity.x = 0;
                        xCollision = true;
                    }
                }
                if (xCollision) break;
            }

            if (xCollision && isCollidingAtPosition(rb->position.x, rb->position.y, enemy, gameMap)) {
                rb->position.x = oldX;
                rb->velocity.x = 0;
            }
        }

        if (isCollidingAtPosition(rb->position.x, rb->position.y, enemy, gameMap)) {
            rb->position.x = oldX;
            rb->position.y = oldY;
            rb->velocity.x = 0;
            rb->velocity.y = 0;
            rb->acceleration.y = 0;
            onGround = checkGround(enemy, gameMap, groundTolerance);
            break;
        }

        if (onGround && std::abs(rb->velocity.x) < velocityThreshold && std::abs(rb->velocity.y) < velocityThreshold) {
            rb->acceleration.y = 0;
            break;
        }
    }

    onGround = checkGround(enemy, gameMap, groundTolerance);
    enemy->setOnGround(onGround);
    if (!onGround && rb->acceleration.y == 0.0f) {
        rb->acceleration.y = 1600.0f;
    } else if (onGround && rb->velocity.y >= 0) {
        rb->velocity.y = 0.0f;
        rb->acceleration.y = 0.0f;
    }

    rb->update(deltaTime);
}


void CollisionHandler::checkCollisions(Bullet* bullet, GameMap* gameMap, float deltaTime) {
    if (!bullet || !gameMap || !bullet->getRigidBody()) return;

    RigidBody* rb = bullet->getRigidBody();
    float tileSize = gameMap->getTileWidth();
    float scaleFactor = gameMap->getScaleFactor();
    float scaledTileSize = tileSize * scaleFactor;
    float velocityThreshold = 0.01f;

    deltaTime = std::min(deltaTime, 1.0f / 240.0f);

    float totalDX = rb->velocity.x * deltaTime;
    float totalDY = rb->velocity.y * deltaTime;

    float maxVelocity = std::max(std::abs(rb->velocity.x), std::abs(rb->velocity.y));
    int steps = std::max(1, static_cast<int>(std::ceil(maxVelocity * deltaTime / (scaledTileSize * 0.1f))));

    for (int i = 0; i < steps; ++i) {
        float stepDX = totalDX / steps;
        float stepDY = totalDY / steps;

        float oldX = rb->position.x;
        float oldY = rb->position.y;

        float newX = oldX + stepDX;
        float newY = oldY + stepDY;

        float epsilon = scaledTileSize * 0.02f;

        if (std::abs(rb->velocity.x) > velocityThreshold || std::abs(rb->velocity.y) > velocityThreshold) {
            rb->position.x = newX;
            rb->position.y = newY;

            float checkX = newX - epsilon;
            float checkY = newY - epsilon;

            int startTileX = std::max(0, static_cast<int>(std::floor((checkX - scaledTileSize) / scaledTileSize)));
            int endTileX = std::min(gameMap->getMapWidth() - 1, static_cast<int>(std::floor((checkX + bullet->getWidth() + scaledTileSize) / scaledTileSize)));
            int startTileY = std::max(0, static_cast<int>(std::floor((checkY - scaledTileSize) / scaledTileSize)));
            int endTileY = std::min(gameMap->getMapHeight() - 1, static_cast<int>(std::floor((checkY + bullet->getHeight() + scaledTileSize) / scaledTileSize)));

            bool collision = false;
            for (int y = startTileY; y <= endTileY; ++y) {
                for (int x = startTileX; x <= endTileX; ++x) {
                    if (!gameMap->isTileSolid(x, y)) continue;

                    float tileLeft = x * scaledTileSize;
                    float tileRight = tileLeft + scaledTileSize;
                    float tileTop = y * scaledTileSize;
                    float tileBottom = tileTop + scaledTileSize;

                    if (rb->position.x + bullet->getWidth() > tileLeft &&
                        rb->position.x < tileRight &&
                        rb->position.y + bullet->getHeight() > tileTop &&
                        rb->position.y < tileBottom) {
                        bullet->deactivate();
                        collision = true;
                        std::cout << "Bullet collision with tile (" << x << ", " << y << ") at pos=(" << rb->position.x << ", " << rb->position.y << ")\n";
                        break;
                    }
                }
                if (collision) break;
            }

            if (collision) break;

            if (isCollidingAtPosition(rb->position.x, rb->position.y, bullet, gameMap)) {
                rb->position.x = oldX;
                rb->position.y = oldY;
                bullet->deactivate();
                std::cout << "Bullet invalid position, deactivated at pos=(" << rb->position.x << ", " << rb->position.y << ")\n";
                break;
            }
        }
    }

    if (bullet->isActive()) {
        rb->update(deltaTime);
    }

    std::cout << "Bullet state - Position: (" << rb->position.x << ", " << rb->position.y << "), Velocity: (" << rb->velocity.x << ", " << rb->velocity.y << "), Active: " << (bullet->isActive() ? "true" : "false") << ", deltaTime: " << deltaTime << "\n";
}

bool CollisionHandler::checkObjectCollision(GameObject* obj1, GameObject* obj2) {
    if (!obj1 || !obj2) return false;

    float obj1X = obj1->getRigidBody()->position.x;
    float obj1Y = obj1->getRigidBody()->position.y;
    float obj1W = obj1->getWidth();
    float obj1H = obj1->getHeight();

    float obj2X = obj2->getRigidBody()->position.x;
    float obj2Y = obj2->getRigidBody()->position.y;
    float obj2W = obj2->getWidth();
    float obj2H = obj2->getHeight();

    bool collision = (obj1X < obj2X + obj2W &&
                      obj1X + obj1W > obj2X &&
                      obj1Y < obj2Y + obj2H &&
                      obj1Y + obj1H > obj2Y);

    if (collision) {
        std::cout << "Collision detected between objects at ("
                  << obj1X << ", " << obj1Y << ") and ("
                  << obj2X << ", " << obj2Y << ")\n";
    }

    return collision;
}
