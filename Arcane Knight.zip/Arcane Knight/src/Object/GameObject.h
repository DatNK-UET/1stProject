#ifndef GAMEOBJECT_H
#define GAMEOBJECT_H

#include "RigidBody.h"
#include <SDL.h>

class GameObject {
public:
    virtual ~GameObject() {}
    virtual void setPosition(float x, float y) = 0;
    virtual void update(float deltaTime) = 0;
    virtual void render(SDL_Renderer* renderer) = 0;
    virtual RigidBody* getRigidBody() const = 0;
    virtual int getWidth() const = 0;
    virtual int getHeight() const = 0;
};

#endif
