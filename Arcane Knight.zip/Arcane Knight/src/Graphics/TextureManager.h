#ifndef TEXTUREMANAGER_H
#define TEXTUREMANAGER_H

#include <SDL.h>
#include <string>

class TextureManager {
public:
    static TextureManager* getInstance();
    void setRenderer(SDL_Renderer* renderer);
    SDL_Texture* loadTexture(const std::string& filename);
    void draw(SDL_Texture* texture, SDL_Rect src, SDL_Rect dst);
    void clean();

private:
    TextureManager();
    static TextureManager* instance;
    SDL_Renderer* renderer;
};

#endif
