#include "TextureManager.h"
#include "SDL_image.h"
#include <iostream>

TextureManager* TextureManager::instance = nullptr;

TextureManager::TextureManager() : renderer(nullptr) {}

TextureManager* TextureManager::getInstance() {
    if (!instance) instance = new TextureManager();
    return instance;
}

void TextureManager::setRenderer(SDL_Renderer* rend) {
    renderer = rend;
}

SDL_Texture* TextureManager::loadTexture(const std::string& filename) {
    if (!renderer) {
        std::cout << "Error: Renderer is null in TextureManager::loadTexture" << std::endl;
        return nullptr;
    }

    SDL_Surface* surface = IMG_Load(filename.c_str());
    if (!surface) {
        std::cout << "Error: Failed to load surface for " << filename << ": " << IMG_GetError() << std::endl;
        return nullptr;
    }

    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    if (!texture) {
        std::cout << "Error: Failed to create texture from surface for " << filename << ": " << SDL_GetError() << std::endl;
    } else {
        std::cout << "Texture created successfully for " << filename << std::endl;
    }

    SDL_FreeSurface(surface);
    return texture;
}

void TextureManager::draw(SDL_Texture* texture, SDL_Rect src, SDL_Rect dst) {
    if (renderer && texture) {
        SDL_RenderCopy(renderer, texture, &src, &dst);
    }
}

void TextureManager::clean() {}
