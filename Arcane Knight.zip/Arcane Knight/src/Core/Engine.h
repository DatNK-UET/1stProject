// Engine.h
#ifndef ENGINE_H
#define ENGINE_H

#include <SDL.h>
#include <SDL_ttf.h>
#include "GameState.h"

enum class GameStateEnum {
    MENU,
    LEVEL_SELECTION,
    PLAYING,
    GAMEOVER,
    LEVEL_COMPLETE
};

class Engine {
private:
    static Engine* instance;
    SDL_Window* window;
    SDL_Renderer* renderer;
    GameState* menu;
    GameState* levelSelection;
    GameState* play;
    GameState* gameOver;
    GameState* levelComplete;
    GameState* currentState;
    bool isRunning;

    Engine();
public:
    static Engine* getInstance();
    bool init(const char* title, int width, int height);
    void run();
    void handleEvents();
    void update(float deltaTime);
    void render();
    void setState(GameStateEnum state);
    GameState* getState(GameStateEnum state);
    void quit();
    void clean();
    SDL_Renderer* getRenderer() { return renderer; }
    bool isRunningState() const { return isRunning; }
    ~Engine();
};

#endif
