#include "Engine.h"
#include "Menu.h"
#include "LevelSelection.h"
#include "Play.h"
#include "GameOver.h"
#include "LevelComplete.h"
#include "TextureManager.h"
#include "Timer.h"
#include "../Audio/AudioManager.h"
#include <iostream>
#include <SDL_image.h>

Engine* Engine::instance = nullptr;

Engine::Engine() : window(nullptr), renderer(nullptr), menu(nullptr), levelSelection(nullptr), play(nullptr), gameOver(nullptr), levelComplete(nullptr), currentState(nullptr), isRunning(false) {}

Engine* Engine::getInstance() {
    if (!instance) instance = new Engine();
    return instance;
}

GameState* Engine::getState(GameStateEnum state) {
    switch (state) {
        case GameStateEnum::MENU:
            return menu;
        case GameStateEnum::LEVEL_SELECTION:
            return levelSelection;
        case GameStateEnum::PLAYING:
            return play;
        case GameStateEnum::GAMEOVER:
            return gameOver;
        case GameStateEnum::LEVEL_COMPLETE:
            return levelComplete;
        default:
            return nullptr;
    }
}

bool Engine::init(const char* title, int width, int height) {
    if (SDL_Init(SDL_INIT_EVERYTHING) != 0 || TTF_Init() != 0) {
        std::cout << "SDL or TTF initialization failed: " << SDL_GetError() << std::endl;
        return false;
    }
    if (!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG)) {
        std::cout << "SDL_image initialization failed: " << IMG_GetError() << std::endl;
        return false;
    }
    window = SDL_CreateWindow(title, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, width, height, 0);
    if (!window) {
        std::cout << "Window creation failed: " << SDL_GetError() << std::endl;
        return false;
    }
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        std::cout << "Renderer creation failed: " << SDL_GetError() << std::endl;
        return false;
    }
    TextureManager::getInstance()->setRenderer(renderer);


    AudioManager::GetInstance()->Init();
    std::cout << "AudioManager initialized" << std::endl;

    menu = new Menu();
    levelSelection = new LevelSelection();
    play = new Play();
    gameOver = new GameOver();
    levelComplete = new LevelComplete();
    setState(GameStateEnum::MENU);
    isRunning = true;
    return true;
}


void Engine::handleEvents() {
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        if (event.type == SDL_QUIT) {
            quit();
        } else if (currentState) {
            currentState->handleEvents(event);
        }
    }
}

void Engine::update(float deltaTime) {
    if (currentState) {
        currentState->update(deltaTime);
    }
}

void Engine::run() {
    Timer* timer = Timer::GetInstance();
    const float targetDeltaTime = 1.0f / 120.0f;

    while (isRunning) {
        timer->Tick();

        while (timer->GetAccumulator() >= targetDeltaTime) {
            handleEvents();
            update(targetDeltaTime);
            timer->ConsumeAccumulator(targetDeltaTime);
        }

        render();
    }
}

void Engine::render() {
    if (!renderer) return;
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderClear(renderer);
    if (currentState) {
        currentState->render(renderer);
    }
    SDL_RenderPresent(renderer);
}

void Engine::setState(GameStateEnum state) {
    switch (state) {
        case GameStateEnum::MENU:
            currentState = menu;
            break;
        case GameStateEnum::LEVEL_SELECTION:
            currentState = levelSelection;
            break;
        case GameStateEnum::PLAYING:
            currentState = play;
            break;
        case GameStateEnum::GAMEOVER:
            currentState = gameOver;
            break;
        case GameStateEnum::LEVEL_COMPLETE:
            currentState = levelComplete;
            break;
    }
    if (currentState) {
        currentState->init();
    }
}

void Engine::quit() {
    isRunning = false;
}

void Engine::clean() {
    AudioManager::GetInstance()->Clean();
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    TTF_Quit();
    SDL_Quit();
}

Engine::~Engine() {
    delete menu;
    delete levelSelection;
    delete play;
    delete gameOver;
    delete levelComplete;
    TextureManager::getInstance()->clean();
    clean();
}
