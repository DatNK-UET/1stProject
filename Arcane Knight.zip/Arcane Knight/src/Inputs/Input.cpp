#include "Input.h"

Input* Input::instance = nullptr;

Input::Input() {
    keyboardState = SDL_GetKeyboardState(nullptr);
}

Input* Input::getInstance() {
    if (!instance) instance = new Input();
    return instance;
}

void Input::update() {
    SDL_PumpEvents();
}

void Input::handleEvent(SDL_Event& event) {}

bool Input::isKeyDown(SDL_Keycode key) {
    return keyboardState[SDL_GetScancodeFromKey(key)];
}
