#ifndef INPUT_H
#define INPUT_H

#include <SDL.h>

class Input {
public:
    static Input* getInstance();
    void update();
    void handleEvent(SDL_Event& event);
    bool isKeyDown(SDL_Keycode key);

private:
    Input();
    static Input* instance;
    const Uint8* keyboardState;
};

#endif
