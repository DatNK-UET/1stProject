// Layer.h
#ifndef LAYER_H
#define LAYER_H

#include <SDL.h>

class Layer {
public:
    virtual void render(SDL_Renderer* renderer, int offsetX, int offsetY) = 0;
    virtual void update() = 0;
    virtual ~Layer() {}
};

#endif
