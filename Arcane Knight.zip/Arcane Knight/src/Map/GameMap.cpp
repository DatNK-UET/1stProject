#include "GameMap.h"
#include "TextureManager.h"
#include <map>

GameMap::GameMap() : tilesetTexture_(nullptr), tileWidth_(16), tileHeight_(16),
                     mapWidth_(120), mapHeight_(40), scaleFactor_(1.0f), offsetX_(0.0f), offsetY_(0.0f) {}

GameMap::GameMap(int width, int height, int tileWidth, int tileHeight)
    : tilesetTexture_(nullptr), tileWidth_(tileWidth), tileHeight_(tileHeight),
      mapWidth_(width), mapHeight_(height), scaleFactor_(1.0f), offsetX_(0.0f), offsetY_(0.0f) {}

void GameMap::addLayer(const std::string& name, const std::vector<int>& tileData, bool hasCollision) {
    TileLayer layer;
    layer.name = name;
    layer.hasCollision = hasCollision;
    layer.tiles.resize(mapHeight_, std::vector<int>(mapWidth_, 0));
    size_t index = 0;
    for (int y = 0; y < mapHeight_; ++y) {
        for (int x = 0; x < mapWidth_; ++x) {
            if (index < tileData.size()) {
                layer.tiles[y][x] = tileData[index++];
            }
        }
    }
    layers_.push_back(layer);
}

void GameMap::render(SDL_Renderer* renderer, int offsetX, int offsetY) {
    static std::map<std::string, SDL_Texture*> textureCache;
    static bool texturesLoaded = false;

    if (!texturesLoaded) {
        textureCache["platforms"] = TextureManager::getInstance()->loadTexture("assets/maps/platforms.png");
        textureCache["world_tileset"] = TextureManager::getInstance()->loadTexture("assets/maps/world_tileset.png");
        textureCache["coin"] = TextureManager::getInstance()->loadTexture("assets/maps/coin.png");
        texturesLoaded = true;
    }

    int startX = std::max(0, static_cast<int>(offsetX / (tileWidth_ * scaleFactor_)));
    int startY = std::max(0, static_cast<int>(offsetY / (tileHeight_ * scaleFactor_)));
    int endX = std::min(mapWidth_, startX + static_cast<int>(800 / (tileWidth_ * scaleFactor_)) + 1);
    int endY = std::min(mapHeight_, startY + static_cast<int>(600 / (tileHeight_ * scaleFactor_)) + 1);


    for (size_t layerIndex = 0; layerIndex < layers_.size(); ++layerIndex) {
        for (int y = startY; y < endY; ++y) {
            for (int x = startX; x < endX; ++x) {
                int tileID = getTileValue(x, y, layerIndex);
                if (tileID == 0) continue;

                SDL_Rect src, dst;
                SDL_Texture* texture = nullptr;
                if (tileID >= 1 && tileID <= 16) {
                    texture = textureCache["platforms"];
                    src = { ((tileID - 1) % 4) * 16, ((tileID - 1) / 4) * 16, 16, 16 };
                } else if (tileID >= 17 && tileID <= 272) {
                    texture = textureCache["world_tileset"];
                    src = { ((tileID - 17) % 16) * 16, ((tileID - 17) / 16) * 16, 16, 16 };
                } else if (tileID >= 273 && tileID <= 284) {
                    texture = textureCache["coin"];
                    src = { ((tileID - 273) % 12) * 16, 0, 16, 16 };
                }

                if (texture) {
                    dst = {
                        static_cast<int>(x * tileWidth_ * scaleFactor_ - offsetX),
                        static_cast<int>(y * tileHeight_ * scaleFactor_ - offsetY),
                        static_cast<int>(tileWidth_ * scaleFactor_),
                        static_cast<int>(tileHeight_ * scaleFactor_)
                    };
                    TextureManager::getInstance()->draw(texture, src, dst);
                }


            }
        }
    }
}

void GameMap::setScaleFactor(float scale) { scaleFactor_ = scale; }

void GameMap::setMapSize(int width, int height) {
    mapWidth_ = width;
    mapHeight_ = height;
    for (auto& layer : layers_) {
        layer.tiles.resize(mapHeight_, std::vector<int>(mapWidth_, 0));
    }
}

void GameMap::setTileSize(int width, int height) {
    tileWidth_ = width;
    tileHeight_ = height;
}

void GameMap::setTilesetTexture(SDL_Texture* texture) { tilesetTexture_ = texture; }

int GameMap::getTileValue(int x, int y, int layerIndex) const {
    if (layerIndex < 0 || layerIndex >= layers_.size()) return 0;
    return (x >= 0 && x < mapWidth_ && y >= 0 && y < mapHeight_) ? layers_[layerIndex].tiles[y][x] : 0;
}

void GameMap::setTileValue(int x, int y, int value, int layerIndex) {
    if (layerIndex < 0 || layerIndex >= layers_.size()) return;
    if (x >= 0 && x < mapWidth_ && y >= 0 && y < mapHeight_) {
        layers_[layerIndex].tiles[y][x] = value;
    }
}

bool GameMap::isTileSolid(int x, int y) const {

    for (const auto& layer : layers_) {
        if (layer.hasCollision && x >= 0 && x < mapWidth_ && y >= 0 && y < mapHeight_) {
            int tileID = layer.tiles[y][x];
            return tileID >= 1 && tileID <= 272;
        }
    }
    return false;
}
