#ifndef MAPPARSER_H
#define MAPPARSER_H

#include <string>
#include <vector>

class GameMap;

class MapParser {
private:
    static MapParser* instance;
    GameMap* gameMap;
    MapParser();
public:
    static MapParser* getInstance();
    bool loadMap(const std::string& filename);
    void clean();
    GameMap* getGameMap() const;
};

#endif
