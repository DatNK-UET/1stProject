
#ifndef TILELAYER_H
#define TILELAYER_H

#include "Layer.h"

class TileLayer : public Layer {
public:
    void render(SDL_Renderer* renderer, int offsetX, int offsetY) override;
    void update() override;
};

#endif
