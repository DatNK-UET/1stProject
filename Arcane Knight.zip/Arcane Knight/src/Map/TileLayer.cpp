#include "TileLayer.h"

void TileLayer::render(SDL_Renderer* renderer, int offsetX, int offsetY) {
    SDL_Rect platform = { 0 - offsetX, 400 - offsetY, 800, 50 };
    SDL_SetRenderDrawColor(renderer, 150, 75, 0, 255);
    SDL_RenderFillRect(renderer, &platform);
}

void TileLayer::update() {}
