#include "MapParser.h"
#include "TextureManager.h"
#include "GameMap.h"
#include "../Vendor/tinyxml2/tinyxml2.h"
#include <sstream>
#include <iostream>
#include <algorithm>

MapParser* MapParser::instance = nullptr;

MapParser::MapParser() : gameMap(nullptr) {}

MapParser* MapParser::getInstance() {
    if (!instance) instance = new MapParser();
    return instance;
}

bool MapParser::loadMap(const std::string& filename) {
    std::cout << "Loading map: " << filename << std::endl;
    clean();

    tinyxml2::XMLDocument doc;
    if (doc.LoadFile(filename.c_str()) != tinyxml2::XML_SUCCESS) {
        std::cout << "Failed to load XML file: " << filename << " (" << doc.ErrorStr() << ")" << std::endl;
        return false;
    }

    tinyxml2::XMLElement* mapElement = doc.FirstChildElement("map");
    if (!mapElement) {
        std::cout << "No map element found in " << filename << std::endl;
        return false;
    }

    int mapWidth = mapElement->IntAttribute("width");
    int mapHeight = mapElement->IntAttribute("height");
    int tileWidth = mapElement->IntAttribute("tilewidth");
    int tileHeight = mapElement->IntAttribute("tileheight");
    float offsetX = mapElement->FloatAttribute("offsetx", 0.0f);
    float offsetY = mapElement->FloatAttribute("offsety", 0.0f);
    std::cout << "Map dimensions: " << mapWidth << "x" << mapHeight << ", tile size: " << tileWidth << "x" << tileHeight << std::endl;

    gameMap = new GameMap(mapWidth, mapHeight, tileWidth, tileHeight);
    if (!gameMap) {
        std::cout << "Failed to create GameMap" << std::endl;
        return false;
    }
    gameMap->setOffset(offsetX, offsetY);

    for (tinyxml2::XMLElement* layerElement = mapElement->FirstChildElement("layer"); layerElement; layerElement = layerElement->NextSiblingElement("layer")) {
        const char* layerName = layerElement->Attribute("name");
        if (!layerName) {
            std::cout << "Layer missing name attribute" << std::endl;
            continue;
        }
        std::cout << "Processing layer: " << layerName << std::endl;

        tinyxml2::XMLElement* dataElement = layerElement->FirstChildElement("data");
        if (dataElement) {
            const char* dataText = dataElement->GetText();
            if (dataText) {
                std::vector<int> tileData;
                std::stringstream ss(dataText);
                std::string token;
                while (std::getline(ss, token, ',')) {
                    try {
                        int gid = std::stoi(token);
                        if (gid < 0 || gid > 284) {
                            std::cout << "Invalid GID " << gid << " in layer " << layerName << ", setting to 0" << std::endl;
                            tileData.push_back(0);
                        } else {
                            tileData.push_back(gid);
                        }
                    } catch (...) {
                        std::cout << "Error parsing GID in layer " << layerName << ", setting to 0" << std::endl;
                        tileData.push_back(0);
                    }
                }
                bool hasCollision = (std::string(layerName) == "Tile Layer 1");
                gameMap->addLayer(layerName, tileData, hasCollision);
                std::cout << "Added layer " << layerName << " with " << tileData.size() << " tiles" << std::endl;
            } else {
                std::cout << "No data text in layer " << layerName << std::endl;
            }
        } else {
            std::cout << "No data element in layer " << layerName << std::endl;
        }
    }

    std::cout << "Map loaded successfully: " << filename << std::endl;
    return true;
}
void MapParser::clean() {
    if (gameMap) {
        std::cout << "Cleaning previous GameMap" << std::endl;
        delete gameMap;
        gameMap = nullptr;
    }
}

GameMap* MapParser::getGameMap() const {
    return gameMap;
}
