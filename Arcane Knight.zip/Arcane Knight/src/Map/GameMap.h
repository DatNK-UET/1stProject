#ifndef GAMEMAP_H
#define GAMEMAP_H

#include <SDL.h>
#include <vector>
#include <string>

class GameMap {
private:
    struct TileLayer {
        std::vector<std::vector<int>> tiles;
        std::string name;
        bool hasCollision;
    };

    std::vector<TileLayer> layers_;
    SDL_Texture* tilesetTexture_;
    int tileWidth_, tileHeight_;
    int mapWidth_, mapHeight_;
    float scaleFactor_;
    float offsetX_, offsetY_;

public:
    GameMap();
    GameMap(int width, int height, int tileWidth, int tileHeight);
    void addLayer(const std::string& name, const std::vector<int>& tileData, bool hasCollision);
    void render(SDL_Renderer* renderer, int offsetX, int offsetY);
    void setScaleFactor(float scale);
    void setMapSize(int width, int height);
    void setTileSize(int width, int height);
    void setTilesetTexture(SDL_Texture* texture);
    int getTileValue(int x, int y, int layerIndex) const;
    void setTileValue(int x, int y, int value, int layerIndex);
    bool isTileSolid(int x, int y) const;
    int getTileWidth() const { return tileWidth_; }
    int getTileHeight() const { return tileHeight_; }
    int getMapWidth() const { return mapWidth_; }
    int getMapHeight() const { return mapHeight_; }
    void setOffset(float x, float y) { offsetX_ = x; offsetY_ = y; }
    float getOffsetX() const { return offsetX_; }
    float getOffsetY() const { return offsetY_; }
    float getScaleFactor() const { return scaleFactor_; }
    size_t getLayerCount() const { return layers_.size(); }
};

#endif
