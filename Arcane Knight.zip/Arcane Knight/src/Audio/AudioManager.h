#ifndef AUDIOMANAGER_H
#define AUDIOMANAGER_H

#include <SDL_mixer.h>
#include <string>
#include <map>

class AudioManager {
public:
    static AudioManager* GetInstance();
    void Init();
    void Clean();
    void PlayMusic(const std::string& filePath, int loops = -1);
    void StopMusic();
    void PauseMusic();
    void ResumeMusic();
    void RestartMusic();
    void PlaySound(const std::string& filePath, int loops = 0);

private:
    AudioManager();
    ~AudioManager();
    static AudioManager* s_Instance;
    Mix_Music* music;
    std::string currentMusicFile;
    int currentLoops;
    std::map<std::string, Mix_Chunk*> soundEffects;
};

#endif
