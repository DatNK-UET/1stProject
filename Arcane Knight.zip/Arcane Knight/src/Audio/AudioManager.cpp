#include "AudioManager.h"
#include <iostream>

AudioManager* AudioManager::s_Instance = nullptr;

AudioManager::AudioManager() : music(nullptr), currentLoops(-1) {}

AudioManager::~AudioManager() {
    Clean();
}

AudioManager* AudioManager::GetInstance() {
    if (!s_Instance) s_Instance = new AudioManager();
    return s_Instance;
}

void AudioManager::Init() {
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        std::cout << "Mix_OpenAudio failed: " << Mix_GetError() << std::endl;
    }
}

void AudioManager::Clean() {
    StopMusic();
    for (auto& sfx : soundEffects) {
        if (sfx.second) {
            Mix_FreeChunk(sfx.second);
        }
    }
    soundEffects.clear();
    Mix_Quit();
}

void AudioManager::PlayMusic(const std::string& filePath, int loops) {
    currentMusicFile = filePath;
    currentLoops = loops;

    if (music) {
        Mix_FreeMusic(music);
        music = nullptr;
    }

    music = Mix_LoadMUS(filePath.c_str());
    if (music) {
        Mix_PlayMusic(music, loops);
    } else {
        std::cout << "Failed to load music: " << Mix_GetError() << std::endl;
    }
}

void AudioManager::StopMusic() {
    if (music) {
        Mix_HaltMusic();
        Mix_FreeMusic(music);
        music = nullptr;
    }
}

void AudioManager::PauseMusic() {
    if (Mix_PlayingMusic()) {
        Mix_PauseMusic();
    }
}

void AudioManager::ResumeMusic() {
    if (Mix_PausedMusic()) {
        Mix_ResumeMusic();
    }
}

void AudioManager::RestartMusic() {
    if (!currentMusicFile.empty()) {
        PlayMusic(currentMusicFile, currentLoops);
    }
}

void AudioManager::PlaySound(const std::string& filePath, int loops) {

    auto it = soundEffects.find(filePath);
    Mix_Chunk* chunk = nullptr;

    if (it == soundEffects.end()) {

        chunk = Mix_LoadWAV(filePath.c_str());
        if (chunk) {
            soundEffects[filePath] = chunk;
        } else {
            std::cout << "Failed to load sound effect " << filePath << ": " << Mix_GetError() << std::endl;
            return;
        }
    } else {
        chunk = it->second;
    }


    if (chunk) {
        Mix_PlayChannel(-1, chunk, loops);
    }
}
