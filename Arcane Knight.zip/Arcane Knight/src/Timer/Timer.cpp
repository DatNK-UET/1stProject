#include "Timer.h"
#include <SDL.h>
#include <iostream>

Timer* Timer::s_Instance = nullptr;

Timer::Timer() : m_DeltaTime(1.0f / 60.0f), m_LastTime(SDL_GetTicks()), m_Accumulator(0.0f) {}

void Timer::Tick() {
    const float targetDeltaTime = 1.0f / 60.0f;
    Uint32 currentTime = SDL_GetTicks();
    float frameTime = (currentTime - m_LastTime) / 1000.0f;
    m_LastTime = currentTime;


    frameTime = std::min(frameTime, targetDeltaTime * 1.5f);

    m_Accumulator += frameTime;
    m_DeltaTime = targetDeltaTime;
}
