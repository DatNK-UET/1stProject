#ifndef TIMER_H
#define TIMER_H

#include "SDL.h"

class Timer {
public:
    void Tick();
    float GetDeltaTime() const { return m_DeltaTime; }
    float GetAccumulator() const { return m_Accumulator; }
    void ConsumeAccumulator(float amount) { m_Accumulator -= amount; }
    static Timer* GetInstance() { return s_Instance ? s_Instance : new Timer(); }

private:
    Timer();
    static Timer* s_Instance;
    float m_DeltaTime;
    Uint32 m_LastTime;
    float m_Accumulator;
};

#endif
