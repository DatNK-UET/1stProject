#include "Camera.h"
#include <algorithm>

Camera* Camera::instance = nullptr;

Camera* Camera::getInstance() {
    if (!instance) instance = new Camera();
    return instance;
}

void Camera::setViewport(int width, int height) {
    viewportWidth = width;
    viewportHeight = height;
}

void Camera::setMapDimensions(int width, int height, float scale) {
    mapWidth = width * scale;
    mapHeight = height * scale;
    scaleFactor = scale;
}

void Camera::setScaleFactor(float scale) {
    scaleFactor = scale;
}

float Camera::getScaleFactor() const {
    return scaleFactor;
}

void Camera::follow(GameObject* targetObj) {
    target = targetObj;
}

void Camera::update() {
    if (!target) return;

    int targetWidth = target->getWidth();
    int targetHeight = target->getHeight();
    float targetX = target->getRigidBody()->position.x;
    float targetY = target->getRigidBody()->position.y;


    float lerp = 0.2f;
    float desiredX = targetX + targetWidth / 2 - viewportWidth / 2;
    float desiredY = targetY + targetHeight / 2 - viewportHeight / 2;
    offsetX = static_cast<int>(offsetX + lerp * (desiredX - offsetX));
    offsetY = static_cast<int>(offsetY + lerp * (desiredY - offsetY));


    offsetX = std::max(0, std::min(offsetX, mapWidth - viewportWidth));
    offsetY = std::max(0, std::min(offsetY, mapHeight - viewportHeight));
}

int Camera::getOffsetX() const { return offsetX; }
int Camera::getOffsetY() const { return offsetY; }
