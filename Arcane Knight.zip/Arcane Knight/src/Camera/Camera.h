#ifndef CAMERA_H
#define CAMERA_H
#include "../Object/GameObject.h"
#include <SDL.h>

class Camera {
private:
    static Camera* instance;
    int viewportWidth, viewportHeight;
    int mapWidth, mapHeight;
    float scaleFactor;
    int offsetX, offsetY;
    GameObject* target;

public:
    static Camera* getInstance();
    void setViewport(int width, int height);
    void setMapDimensions(int width, int height, float scale = 1.0f);
    void setScaleFactor(float scale);
    float getScaleFactor() const;
    void follow(GameObject* target);
    void update();
    int getOffsetX() const;
    int getOffsetY() const;
};

#endif
